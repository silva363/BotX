/* eslint-disable react-hooks/exhaustive-deps */
"use client";
import Navbar from "@/components/navbar/navbar";
import {
  BlocoBtn,
  Form,
  ModalEdit,
  TBody,
  THeader,
  Table,
  Td,
  Th,
  Tr,
} from "./styles";
import axios from "axios";
import { useEffect, useState } from "react";
import { FaRegEdit, FaChartBar, FaArrowUp, FaRobot, FaArrowDown, FaEyeSlash, FaEye } from "react-icons/fa";
import Link from "next/link";
import { IoIosCloseCircleOutline } from "react-icons/io";
import { toast } from "react-toastify";
import { convertStringToNumber, getMinifiedAddress } from "@/app/utils/data";
import { useRouter } from 'next/navigation'
import { useGlobalContext } from "@/components/store/authContext";
import Toggle from 'react-toggle'
import Loader from "@/components/loader/loader";
import Badge from "@/components/badge/Badge";

export default function Home() {
  const [listBot, setListBot] = useState<TradeBotData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isReloading, setIsReloading] = useState(false);
  const [isLoadingBotList, setIsLoadingBotList] = useState(true);
  const [isLoadingTokenList, setIsLoadingTokenList] = useState(true);
  const [isLoadingEdit, setIsLoadingEdit] = useState(false);
  const [isChangeBotStatus, setIsChangeBotStatus] = useState(false);
  const [tokenList, setTokenList] = useState<Token[]>([]);
  const [configAdvanced, setConfigAdvanced] = useState(false);
  const [showEditModal, setShowEditModal] = useState<any>(false);
  const [botType, setBotType] = useState('');
  const [botIsHidden, setBotIsHidden] = useState(0);
  const [editBotData, setEditBotData] = useState<TradeBotData | any>({
    name: "",
    helper_private_key: "",
    account_private_key: "",
    destiny_address: "",
    target_price: 1,
    min_amount: 0.1,
    max_amount: 0.3,
    min_delay: 60,
    max_delay: 120,
    target_balance: 0,
    holder_percent: 0,
    airdrop_time: 60,
    cycles: 1,
    cycle_ghosts: 5,
    cycle_delay: 90,
    actual_cycle: 0,
    token_symbol: "",
    slippage_tolerance: 5,
    delay_to_start: 0,
    strategy: "",
    friendly_name: "",
    work_start: '00:00',
    work_end: '00:00',
  });
  const { token } = useGlobalContext();
  const { push } = useRouter();

  useEffect(() => {
    async function loadBotList() {
      try {
        setIsChangeBotStatus(false);

        if (isReloading) {
          setIsLoading(true);
        }

        const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_APP_URL}/api/trade-bot/list`, { authtoken: token, type: botType, isHidden: botIsHidden });

        if (response.data.success) {
          if (isChangeBotStatus) {
            setListBot([]);
            setTimeout(() => {
              setListBot(response.data.data);
            }, 300);

          } else {
            setListBot(response.data.data);
          }
        } else {
          if (response.data.message) {
            toast.error(response.data.message);
          } else {
            toast.error(response.data);
          }
        }
      } catch (error: any) {
        toast.error(error.message);
      } finally {
        setIsLoading(false);
        setIsReloading(false);
      }
    }

    async function loadTokenlist() {
      try {
        const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_APP_URL}/api/acceptedTokens/list`, { authtoken: token });

        setTokenList(response.data.data);
      } catch (error: any) {
        setIsLoading(false);
        toast.error(error.message);
      }
    };

    if (token) {
      if ((isLoading && isLoadingBotList) || isChangeBotStatus) {
        setIsLoadingBotList(false);
        loadBotList();
      }

      if (isLoading && isLoadingTokenList) {
        setIsLoadingTokenList(false);
        loadTokenlist();
      }

      setTimeout(() => {
        setIsLoading(false);
      }, 10000);
    }
  }, [
    listBot,
    tokenList,
    isLoading,
    isLoadingBotList,
    isChangeBotStatus,
    isLoadingTokenList,
    editBotData,
    botType,
    token
  ]);

  const handleChange = async (uuid: string, active: number, type: string) => {
    try {
      let endpoint = "";

      if (type == "buy") {
        endpoint = "play-buy";

        if (active) {
          endpoint = "stop-buy";
        } else {
          /*
         if (!confirm("Você realmente deseja ativar este bot?")) {
           return;
         }
         */
        }
      } else if (type == "sell") {
        endpoint = "play-sell";

        if (active) {
          endpoint = "stop-sell";
        } else {
          /*
          if (!confirm("Você realmente deseja ativar este bot?")) {
            return;
          }
          */
        }
      }

      if (endpoint == "") {
        return;
      }

      setIsLoading(true);

      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_APP_URL}/api/trade-bot/run`,
        {
          uuid,
          endpoint,
          authtoken: token
        }
      );

      if (response.data.success) {
        toast.success(response.data.message);
        setIsChangeBotStatus(true);
      } else {
        if (response.data.message) {
          toast.error(response.data.message);
        } else {
          toast.error(response.data);
        }

        setIsLoading(false);
      }
    } catch (error: any) {
      setIsLoading(false);
      toast.error(error.message);
    }
  };

  const handleSave = async (e: any) => {
    try {
      e.preventDefault();
      setIsLoadingEdit(true);

      const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_APP_URL}/api/trade-bot/edit`, { editBotData, authtoken: token });

      setIsLoadingEdit(false);

      if (response.data.success) {
        toast.success(response.data.message);
        handleCloseEditClick();
        setIsReloading(true);
        setIsChangeBotStatus(true);
      } else {
        if (response.data.message) {
          toast.error(response.data.message);
        } else {
          toast.error(response.data);
        }
      }
    } catch (error: any) {
      setIsLoadingEdit(false);
      toast.error(error.message);
    }
  };

  const handleEditClick = (bot: any) => {
    setEditBotData(bot);
    setShowEditModal(true);
  };

  const handleCloseEditClick = () => {
    setShowEditModal(false);
    setConfigAdvanced(false);
  };

  const handleEdit = async (e: any) => {
    const { name, value } = e.target;
    setEditBotData((prevData: any) => ({
      ...prevData,
      [name]: name === "type" ? value : value || value,
    }));
  };

  const pageExecutions = (uuid: string, botType: string, botName: string) => {
    push(`/dashboard/trade-bots/executions?uuid=${uuid}&type=${botType}&name=${botName}`);
  };

  const handleHide = async (uuid: string, isHidden: number) => {
    try {
      let extraText = 'ocultar';

      if (isHidden) {
        extraText = 'voltar a exibir';
      }

      if (!confirm(`Você tem certeza que deseja ${extraText} este bot?`)) {
        return;
      }

      setIsLoadingEdit(true);

      const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_APP_URL}/api/trade-bot/hide-unhide`, { uuid, authtoken: token });

      setIsLoadingEdit(false);

      if (response.data.success) {
        toast.success(response.data.message);
        setIsChangeBotStatus(true);
      } else {
        if (response.data.message) {
          toast.error(response.data.message);
        } else {
          toast.error(response.data);
        }
      }
    } catch (error: any) {
      setIsLoadingEdit(false);
      toast.error(error.message);
    }
  };

  const LoadQueueSwaps = async (bot: TradeBotData) => {
    try {
      if (bot.mode != "queue") {
        return;
      }

      setIsLoading(true);

      const response = await axios.post(
        `${process.env.NEXT_PUBLIC_BASE_APP_URL}/api/trade-bot/queue-swaps`,
        {
          uuid: bot.uuid,
          authtoken: token
        }
      );

      if (response.data.success) {
        setListBot((listBot) =>
          listBot.map((b) =>
            b.uuid === bot.uuid
              ? { ...b, actual_queue: response.data.data.count }
              : b
          )
        );
      } else {
        if (response.data.message) {
          toast.error(response.data.message);
        } else {
          toast.error(response.data);
        }
      }

      setIsLoading(false);
    } catch (error: any) {
      setIsLoading(false);
      toast.error(error.message);
    }
  };

  return (
    <>
      <Navbar />
      {isLoading || isLoadingEdit ? (
        <Loader></Loader>
      ) : (
        <>
          <div className="header-container">
            <div className="header-title">
              <h2>Bots de Compra e Venda</h2>
            </div>
            <div className="row">
              <div className="col-6">
                <p>Estratégia</p>
                <div className="select-wrapper">
                  <select value={botType} onChange={(e) => {
                    setBotType(e.target.value);
                    setIsChangeBotStatus(true);
                    setIsReloading(true);
                  }}>
                    <option value="">Todas</option>
                    <option value="buy">Compra</option>
                    <option value="sell">Venda</option>
                  </select>
                </div>
              </div>
              <div className="col-6">
                <p>Visibilidade</p>
                <div className="select-wrapper">
                  <select value={botIsHidden} onChange={(e) => {
                    console.log(e.target.value)
                    setBotIsHidden(Number(e.target.value));
                    setIsChangeBotStatus(true);
                    setIsReloading(true);
                  }}>
                    <option value="0">Em exibição</option>
                    <option value="1">Ocultos</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="table-container">
            <Table>
              <THeader>
                <Th style={{ maxWidth: "80px" }}>Modo</Th>
                <Th style={{ maxWidth: "120px" }}>Estratégia</Th>
                <Th>
                  Nome do bot
                </Th>
                <Th style={{ maxWidth: "140px", textAlign: "center" }}>Execução</Th>
                <Th>
                  Cart. de Dest.
                  <br />
                  Nome amig.
                </Th>
                <Th>
                  Valor Mínimo
                  <br />
                  Valor Máximo
                </Th>
                <Th>
                  T. Mínimo
                  <br />
                  T. Máximo
                  <br />
                  Atraso Ini.
                </Th>
                <Th style={{ maxWidth: "120px" }}>
                  Início/Pausa
                  <br />
                  Holder
                </Th>
                <Th style={{ maxWidth: "120px" }}>
                  Cic. Atual/Tot.
                </Th>
                <Th style={{ maxWidth: "80px" }}>Ações</Th>
              </THeader>

              <TBody>
                {listBot?.map((bot) => (
                  <Tr key={bot.id}>
                    <Td style={{ maxWidth: "80px" }}>
                      <div onClick={() => LoadQueueSwaps(bot)} style={{ cursor: "pointer" }}>
                        <Badge size="small" variant={bot.mode === "linear" ? "default" : "success"}   >
                          {bot.mode === "linear" ? "Comum" : `Fila (${bot.actual_queue !== undefined ? bot.actual_queue : "~"})`}
                        </Badge>
                      </div>
                    </Td>
                    <Td style={{ maxWidth: "120px" }}>
                      {bot.strategy === "buy" ? "Compra" : "Venda"}
                    </Td>
                    <Td>
                      {bot.name}
                      <br />
                      {bot.friendly_name}
                    </Td>
                    <Td style={{ maxWidth: "140px", textAlign: "center" }}>
                      <Toggle
                        id='biscuit-status'
                        icons={{
                          checked: <FaRobot />,
                          unchecked: null,
                        }}
                        defaultChecked={bot.active === 1}
                        onChange={() => handleChange(bot.uuid, bot.active, bot.strategy)}
                      />
                    </Td>
                    <Td>
                      {getMinifiedAddress(bot.destiny_address)}
                      <br />
                      {bot.destiny_friendly_name}
                    </Td>
                    <Td>
                      {bot.min_amount}
                      <br />
                      {bot.max_amount}
                    </Td>
                    <Td>
                      {bot.min_delay} segundos
                      <br />
                      {bot.max_delay} segundos
                      <br />
                      {bot.delay_to_start} minutos
                    </Td>
                    <Td style={{ maxWidth: "120px" }}>
                      {bot.work_start}h / {bot.work_end}h
                      <br />
                      {bot.holder_percent.toFixed(2)}%
                    </Td>
                    <Td className="text-center" style={{ maxWidth: "120px" }}>
                      {bot.actual_cycle}/{bot.cycles}
                    </Td>
                    <Td style={{ maxWidth: "80px" }}>
                      <FaChartBar
                        size={15}
                        onClick={() => pageExecutions(bot.uuid, bot.strategy, bot.name)}
                        className="icon"
                        style={{ margin: "4px" }}
                      />
                      <FaRegEdit
                        size={15}
                        onClick={() => handleEditClick(bot)}
                        className="icon"
                        style={{ margin: "4px" }}
                      />
                      {
                        bot.is_hidden ? <FaEye
                          size={15}
                          onClick={() => handleHide(bot.uuid, bot.is_hidden)}
                          className="icon"
                          style={{ margin: "4px" }}
                        /> :
                          <FaEyeSlash
                            size={15}
                            onClick={() => handleHide(bot.uuid, bot.is_hidden)}
                            className="icon"
                            style={{ margin: "4px" }}
                          />
                      }
                    </Td>
                  </Tr>
                ))}
              </TBody>
            </Table>
          </div>

          <div className="container">
            <Link href="create-bot" >
              <button className="floating-button">+</button>
            </Link>
          </div>

          {showEditModal && editBotData && (
            <ModalEdit>
              <IoIosCloseCircleOutline
                size={35}
                color="#FF577C"
                onClick={() => setShowEditModal(false)}
              />
              <ul>
                <Form onSubmit={handleSave}>
                  <div className="section">
                    <h2>Dados Gerais</h2>
                    <span>
                      <label>Nome do Bot</label>
                      <input
                        type="text"
                        name="name"
                        onChange={handleEdit}
                        value={editBotData.name}
                      />
                    </span>
                  </div>

                  <div className="section mt-5">
                    <h2>Chaves de Acesso</h2>
                    <span>
                      <label>Nome amigavel da chave privada (Opcional)</label>
                      <input
                        type="text"
                        name="friendly_name"
                        onChange={handleEdit}
                        placeholder="You can add a friendly name"
                        value={editBotData?.friendly_name}
                      />
                    </span>
                  </div>

                  <div className="section mt-5">
                    <h2>Estratégia</h2>

                    <span>
                      <label>Modo de execução</label>
                      <select name="mode"
                        value={editBotData.mode}
                        onChange={handleEdit}>
                        <option value="linear">Comum</option>
                        <option value="queue">Fila</option>
                      </select>
                    </span>

                    {editBotData.mode === "queue" && (
                      <span>
                        <label>Tamanho máximo da fila</label>
                        <input
                          type="number"
                          name="max_queue"
                          value={editBotData.max_queue}
                          onChange={handleEdit}
                        />
                      </span>
                    )}

                    <span>
                      <label>Selecione o token</label>
                      <select
                        name="token_symbol"
                        value={editBotData.token_symbol}
                        onChange={handleEdit}>
                        <option value="">Selecione</option>
                        {tokenList && tokenList?.length > 0
                          ? tokenList.map((token: any) => (
                            <option key={token.id} value={token.symbol}>
                              {token.name}
                            </option>
                          ))
                          : ""}
                      </select>
                    </span>
                  </div>

                  <div className="section mt-5">
                    <h2>Destino</h2>
                    <span>
                      <label>Carteira de destino</label>
                      <input
                        type="text"
                        name="destiny_address"
                        onChange={handleEdit}
                        value={editBotData.destiny_address}
                      />
                    </span>
                    <span>
                      <label>Nome amigavel da carteira de destino (Opcional)</label>
                      <input
                        type="text"
                        name="destiny_friendly_name"
                        onChange={handleEdit}
                        placeholder="You can add a friendly name"
                        value={editBotData?.destiny_friendly_name}
                      />
                    </span>
                  </div>

                  {/*
                  <span>
                    <label>Preço alvo</label>
                    <input
                      type="number"
                      name="target_price"
                      value={convertStringToNumber(editBotData.target_price)}
                      onChange={handleEdit}
                    />
                  </span>
                  <span>
                    <label>Limite para utilizar (Matic/Token) (Opcional)</label>
                    <input
                      type="number"
                      name="target_balance"
                      value={editBotData.target_balance}
                      onChange={handleEdit}
                    />
                  </span>
                  */}

                  <div className="section mt-5">
                    <h2>Horários</h2>
                    <span>
                      <label>Horário de início</label>
                      <input
                        type="time"
                        name="work_start"
                        value={editBotData.work_start}
                        onChange={handleEdit}
                        step="60"
                        lang="pt-BR"
                      />
                    </span>
                    <span>
                      <label>Horário de pausa</label>
                      <input
                        type="time"
                        name="work_end"
                        value={editBotData.work_end}
                        onChange={handleEdit}
                        step="60"
                        lang="pt-BR"
                      />
                    </span>
                  </div>

                  <span className="configAdvanced">
                    <h1>Configurações Avançadas</h1>
                    <button type="button" onClick={() => setConfigAdvanced(!configAdvanced)}>
                      {configAdvanced ? <FaArrowUp size={16} /> : <FaArrowDown size={16} />}
                    </button>
                  </span>
                  {configAdvanced && (
                    <>
                      <span>
                        <label>Valor mínimo de transação</label>
                        <input
                          type="number"
                          name="min_amount"
                          value={editBotData.min_amount}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Valor máximo de transação</label>
                        <input
                          type="number"
                          name="max_amount"
                          value={editBotData.max_amount}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Tempo Mínimo (seg)</label>
                        <input
                          type="number"
                          name="min_delay"
                          value={editBotData.min_delay}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Tempo Máximo (seg)</label>
                        <input
                          type="number"
                          name="max_delay"
                          value={editBotData.max_delay}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Hold p. wallet (%)</label>
                        <input
                          type="number"
                          name="holder_percent"
                          value={editBotData.holder_percent}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Ciclos</label>
                        <input
                          type="number"
                          name="cycles"
                          value={editBotData.cycles}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Ghosts por ciclo</label>
                        <input
                          type="number"
                          name="cycle_ghosts"
                          value={editBotData.cycle_ghosts}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Atraso entre ciclos (segundos)</label>
                        <input
                          type="number"
                          name="cycle_delay"
                          value={editBotData.cycle_delay}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Airdrop time (min)</label>
                        <input
                          type="number"
                          name="airdrop_time"
                          value={editBotData.airdrop_time}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Taxa de derrapagem</label>
                        <input
                          type="number"
                          name="slippage_tolerance"
                          value={editBotData.slippage_tolerance}
                          onChange={handleEdit}
                        />
                      </span>
                      <span>
                        <label>Atraso de inicialização (min)</label>
                        <input
                          type="number"
                          name="delay_to_start"
                          value={editBotData.delay_to_start}
                          onChange={handleEdit}
                        />
                      </span>
                    </>
                  )}
                  <BlocoBtn>
                    <Link href="#">
                      <button type="button" onClick={handleCloseEditClick}>Fechar</button>
                    </Link>
                    <button type="submit">Salvar</button>
                  </BlocoBtn>
                </Form>
              </ul>
            </ModalEdit>
          )}
        </>
      )}
    </>
  );
}
