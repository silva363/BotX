import React from 'react';

type BadgeProps = {
    children: React.ReactNode;
    variant?: 'default' | 'success' | 'warning' | 'error';
    size?: 'small' | 'medium' | 'large';
};

const Badge: React.FC<BadgeProps> = ({ children, variant = 'default', size = 'medium' }) => {
    // Definindo as classes do Bootstrap dependendo das props
    const badgeClasses = `
    badge 
    ${variant === 'default' ? 'bg-secondary text-light' : ''}
    ${variant === 'success' ? 'bg-success text-light' : ''}
    ${variant === 'warning' ? 'bg-warning text-dark' : ''}
    ${variant === 'error' ? 'bg-danger text-light' : ''}
    ${size === 'small' ? 'fs-6' : ''}  // Font size smaller
    ${size === 'medium' ? 'fs-5' : ''} // Font size medium
    ${size === 'large' ? 'fs-4' : ''}  // Font size larger
  `;

    return <span className={badgeClasses}>{children}</span>;
};

export default Badge;
