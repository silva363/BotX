# BotX Vercel Deployment Guide

This guide provides quick steps to deploy BotX on Vercel with a PlanetScale database.

## Quick Start

1. **Set up PlanetScale Database**
   - Sign up at https://planetscale.com
   - Create a database named "botx-db"
   - Import SQL files from `BotX_back_end-main/database/`
   - Get your connection string

2. **Deploy Backend**
   - Choose a platform: Railway, Render, or similar
   - Set environment variables from `.env.vercel`
   - Update `DATABASE_URL` with your PlanetScale connection string

3. **Deploy Frontend on Vercel**
   - Push code to GitHub
   - Import repository in Vercel
   - Set environment variables from `.env.vercel`
   - Update `NEXT_PUBLIC_API_URL` with your backend URL
   - Update `NEXT_PUBLIC_BASE_APP_URL` with your Vercel app URL

4. **Add a User to the Database**
   ```sql
   INSERT INTO users (uuid, wallet_address, created_at, updated_at) 
   VALUES (UUID(), 'your_wallet_address', NOW(), NOW());
   ```

## Detailed Instructions

For detailed deployment instructions, see [VERCEL_DEPLOYMENT.md](VERCEL_DEPLOYMENT.md).

## Environment Variables

### Backend
- `DATABASE_URL`: PlanetScale connection string
- `API_SECRET_KEY`: API key for authentication
- `JWT_SECRET_KEY`: Secret for JWT tokens
- `ALCHEMY_KEY`: Your Alchemy API key

### Frontend
- `NEXT_PUBLIC_API_URL`: URL to your backend API
- `NEXT_PUBLIC_BASE_APP_URL`: URL to your Vercel app
- `NEXT_PUBLIC_API_KEY`: Same as backend's API_SECRET_KEY
- `NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID`: Your WalletConnect project ID
