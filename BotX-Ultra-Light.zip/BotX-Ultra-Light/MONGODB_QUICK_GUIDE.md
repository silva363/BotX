# BotX MongoDB Deployment Quick Guide

This is a simplified guide for deploying BotX with MongoDB Atlas.

## Step 1: Set up MongoDB Atlas

1. Sign up at [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register)
2. Create a free M0 cluster
3. Set up a database user (username and password)
4. Allow access from anywhere (Network Access → Add IP Address → Allow Access from Anywhere)
5. Get your connection string: Connect → Connect your application

## Step 2: Initialize the Database

1. Update the connection string in `BotX_back_end-main/.env.mongodb`:
   ```
   MONGODB_URI=mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/botx-db?retryWrites=true&w=majority
   ```

2. Run the initialization script:
   ```bash
   cd BotX_back_end-main
   ./init-mongodb.sh 'your_mongodb_connection_string' 'your_wallet_address'
   ```

## Step 3: Deploy the Backend

1. Sign up at [Render](https://render.com)
2. Create a new Web Service
3. Connect your GitHub repository
4. Configure:
   - Name: botx-backend
   - Root Directory: BotX_back_end-main
   - Environment: Node
   - Build Command: `yarn install && yarn build`
   - Start Command: `yarn start`
5. Add environment variables from `.env.mongodb`
6. Deploy

## Step 4: Deploy the Frontend on Vercel

1. Sign up at [Vercel](https://vercel.com)
2. Create a new project
3. Import your GitHub repository
4. Configure:
   - Framework Preset: Next.js
   - Root Directory: BotX-main
5. Add environment variables:
   ```
   NEXT_PUBLIC_API_URL=https://your-backend-url.onrender.com/api
   NEXT_PUBLIC_BASE_APP_URL=https://your-vercel-app-url.vercel.app
   NEXT_PUBLIC_API_KEY=botx_api_secret_key_123
   NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID=47d5b0df6be065b6d01ce8a6b5b64762
   NEXT_PUBLIC_WALLET_CONNECT_PROJECT_NAME=BotX
   ```
6. Deploy

## Step 5: Test the Deployment

1. Open your Vercel deployment URL
2. Connect your wallet
3. Sign in to the application

## Need More Help?

See the detailed guide in [MONGODB_DEPLOYMENT.md](MONGODB_DEPLOYMENT.md)
