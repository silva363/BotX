# BotX Trading Bot

This repository contains the BotX trading bot application, which includes:

- A Next.js frontend
- A Node.js backend
- MongoDB integration

## Project Structure

- `/frontend`: The Next.js frontend application
- `/backend`: The Node.js backend application

## Deployment

For detailed deployment instructions, see:

- [Vercel MongoDB Deployment Guide](VERCEL_MONGODB_DEPLOYMENT.md)
- [MongoDB Quick Guide](MONGODB_QUICK_GUIDE.md)
- [Vercel README](README_VERCEL.md)

## Getting Started

### Backend

```bash
cd backend
yarn install
yarn dev
```

### Frontend

```bash
cd frontend
yarn install
yarn dev
```

## Environment Variables

### Backend

Create a `.env` file in the backend directory with the following variables:

```
WORKSPACE=prod
APP_NAME=BotX
PORT=3001
JWT_EXPIRATION=1y
API_SECRET_KEY=your_api_secret_key
JWT_SECRET_KEY=your_jwt_secret_key
MONGODB_URI=your_mongodb_connection_string
ALCHEMY_KEY=your_alchemy_key
ALCHEMY_API=https://polygon-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}
ENCRYPT_32BIT_KEY=your_32bit_encryption_key
ENCRYPT_16BIT_IV_KEY=your_16bit_iv_key
SECRET_KEY=your_secret_key
CHAIN_ID=137
WITH_PAYMENT=n
```

### Frontend

Create a `.env.local` file in the frontend directory with the following variables:

```
NEXT_PUBLIC_API_URL=http://localhost:3001/api
NEXT_PUBLIC_BASE_APP_URL=http://localhost:3000
NEXT_PUBLIC_API_KEY=your_api_secret_key
NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID=your_wallet_connect_project_id
NEXT_PUBLIC_WALLET_CONNECT_PROJECT_NAME=BotX
```
