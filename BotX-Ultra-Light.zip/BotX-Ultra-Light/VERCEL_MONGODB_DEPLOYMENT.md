# BotX Vercel Deployment Guide with MongoDB

This guide provides step-by-step instructions for deploying the full BotX application on Vercel with MongoDB Atlas.

## Prerequisites

- GitHub account
- Vercel account (https://vercel.com)
- MongoDB Atlas account (https://www.mongodb.com/cloud/atlas)
- Alchemy account (https://www.alchemy.com)
- WalletConnect Project ID (https://cloud.walletconnect.com)

## Step 1: Set Up MongoDB Atlas

1. **Create a MongoDB Atlas account**:
   - Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas/register)
   - Sign up for a free account

2. **Create a new cluster**:
   - After signing up, click "Build a Database"
   - Choose the FREE tier (M0)
   - Select a cloud provider and region close to your users
   - Click "Create Cluster" (this may take a few minutes)

3. **Set up database access**:
   - In the left sidebar, click "Database Access" under SECURITY
   - Click "Add New Database User"
   - Create a username and password (save these credentials)
   - Set "Database User Privileges" to "Read and write to any database"
   - Click "Add User"

4. **Set up network access**:
   - In the left sidebar, click "Network Access" under SECURITY
   - Click "Add IP Address"
   - For Vercel deployment, click "Allow Access from Anywhere"
   - Click "Confirm"

5. **Get your connection string**:
   - Once your cluster is created, click "Connect"
   - Select "Connect your application"
   - Copy the connection string (it will look like: `mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority`)
   - Replace `<password>` with your database user's password
   - Add the database name to the URI: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/botx-db?retryWrites=true&w=majority`

## Step 2: Initialize the MongoDB Database

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/BotX.git
   cd BotX/BotX_back_end-main
   ```

2. **Install dependencies**:
   ```bash
   yarn install
   ```

3. **Update the MongoDB connection string**:
   - Open `.env.mongodb` and replace the `MONGODB_URI` with your connection string
   - Copy this file to `.env`: `cp .env.mongodb .env`

4. **Initialize the database**:
   ```bash
   ./init-mongodb.sh 'your_mongodb_connection_string' 'your_wallet_address'
   ```

## Step 3: Deploy the Backend on Vercel

1. **Push your code to GitHub**:
   - Create a new repository on GitHub
   - Push your code to the repository

2. **Import the backend project in Vercel**:
   - Go to [Vercel](https://vercel.com)
   - Click "Add New" → "Project"
   - Import your GitHub repository
   - Select the "BotX_back_end-main" directory as the root directory

3. **Configure the project**:
   - Framework Preset: Other
   - Build Command: `yarn install && yarn build`
   - Output Directory: `dist`
   - Install Command: `yarn install`

4. **Add environment variables**:
   - Click "Environment Variables"
   - Add all the variables from your `.env.mongodb` file, including:
     ```
     WORKSPACE=prod
     APP_NAME=BotX
     PORT=3001
     JWT_EXPIRATION=1y
     API_SECRET_KEY=botx_api_secret_key_123
     JWT_SECRET_KEY=botx_jwt_secret_key_456
     MONGODB_URI=your_mongodb_connection_string
     ALCHEMY_KEY=your_alchemy_key
     ALCHEMY_API=https://polygon-mainnet.g.alchemy.com/v2/${ALCHEMY_KEY}
     ENCRYPT_32BIT_KEY=botx_32bit_encryption_key_789012
     ENCRYPT_16BIT_IV_KEY=botx_16bit_iv_key
     SECRET_KEY=botx_secret_key_345678
     CHAIN_ID=137
     WITH_PAYMENT=n
     ```

5. **Deploy the backend**:
   - Click "Deploy"
   - Wait for the deployment to complete
   - Note the URL of your backend (e.g., https://botx-backend.vercel.app)

## Step 4: Deploy the Frontend on Vercel

1. **Import the frontend project in Vercel**:
   - Go to [Vercel](https://vercel.com)
   - Click "Add New" → "Project"
   - Import your GitHub repository
   - Select the "BotX-main" directory as the root directory

2. **Configure the project**:
   - Framework Preset: Next.js
   - Build Command: `yarn build`
   - Output Directory: `.next`
   - Install Command: `yarn install`

3. **Add environment variables**:
   - Click "Environment Variables"
   - Add the following variables:
     ```
     NEXT_PUBLIC_API_URL=https://your-backend-url.vercel.app/api
     NEXT_PUBLIC_BASE_APP_URL=https://your-frontend-url.vercel.app
     NEXT_PUBLIC_API_KEY=botx_api_secret_key_123
     NEXT_PUBLIC_WALLET_CONNECT_PROJECT_ID=your_wallet_connect_project_id
     NEXT_PUBLIC_WALLET_CONNECT_PROJECT_NAME=BotX
     ```
   - Replace `your-backend-url.vercel.app` with your actual backend URL
   - Replace `your-frontend-url.vercel.app` with your frontend URL (you can use a placeholder and update it after deployment)

4. **Deploy the frontend**:
   - Click "Deploy"
   - Wait for the deployment to complete
   - Note the URL of your frontend (e.g., https://botx-frontend.vercel.app)

5. **Update the frontend URL**:
   - If you used a placeholder for `NEXT_PUBLIC_BASE_APP_URL`, go to the project settings
   - Update the environment variable with the actual frontend URL
   - Redeploy the frontend

## Step 5: Test the Deployment

1. **Open your frontend URL in a browser**
2. **Connect your wallet**
3. **Sign in to the application**
4. **Verify that you can access the dashboard**
5. **Test creating and managing bots**

## Troubleshooting

### Backend Deployment Issues

If you encounter issues with the backend deployment:

1. **Check the Vercel logs**:
   - Go to your backend project in Vercel
   - Click on the latest deployment
   - Check the build and runtime logs for errors

2. **Verify environment variables**:
   - Make sure all required environment variables are set correctly
   - Check that the MongoDB connection string is correct

3. **Check MongoDB connection**:
   - Verify that your MongoDB Atlas cluster is running
   - Ensure that network access is allowed from anywhere

### Frontend Deployment Issues

If you encounter issues with the frontend deployment:

1. **Check the Vercel logs**:
   - Go to your frontend project in Vercel
   - Click on the latest deployment
   - Check the build and runtime logs for errors

2. **Verify environment variables**:
   - Make sure all required environment variables are set correctly
   - Check that the backend URL is correct

3. **Check API connection**:
   - Open your browser's developer tools
   - Check the Network tab for API requests
   - Verify that requests to the backend are successful

### Authentication Issues

If you cannot sign in:

1. **Check the user in MongoDB**:
   - Connect to your MongoDB Atlas cluster
   - Check that a user with your wallet address exists in the `users` collection

2. **Check JWT configuration**:
   - Verify that the JWT secret keys match between frontend and backend
   - Check the browser console and backend logs for specific error messages

## Maintenance

### Updating the Application

To update the application:

1. **Make changes to your local repository**
2. **Push the changes to GitHub**
3. **Vercel will automatically redeploy the application**

### Monitoring

To monitor the application:

1. **Use Vercel's built-in monitoring**:
   - Go to your project in Vercel
   - Click on "Analytics" to view performance metrics

2. **Use MongoDB Atlas monitoring**:
   - Go to your cluster in MongoDB Atlas
   - Click on "Metrics" to view database performance

## Security Considerations

1. **API Keys**:
   - Keep your API keys secure
   - Do not commit them to public repositories

2. **JWT Secrets**:
   - Use strong, unique JWT secret keys
   - Rotate them periodically

3. **Database Access**:
   - Limit database access to only necessary IP addresses
   - Use strong passwords for database users

4. **Environment Variables**:
   - Use Vercel's environment variables for sensitive information
   - Do not expose sensitive information in client-side code
