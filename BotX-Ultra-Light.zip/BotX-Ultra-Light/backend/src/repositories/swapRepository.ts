import doQuery from '../utils/db';
import { Swap } from '../models/Swap';
import { BotExecution } from '../models/BotExecution';

export class SwapRepository {
  async create(swap: Swap): Promise<Swap> {
    try {
      const sql = `
        INSERT INTO swaps (
        user_id, 
        bot_execution, 
        bot_uuid,
        private_key,
        amount,
        token_name,
        token_symbol,
        token_address,
        swap_type,
        bot_type,
        mode
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const values = [
        swap.user_id,
        swap.bot_execution,
        swap.bot_uuid,
        swap.private_key,
        swap.amount,
        swap.token_name,
        swap.token_symbol,
        swap.token_address,
        swap.swap_type.toLowerCase(),
        swap.bot_type,
        swap.mode
      ];

      await doQuery(sql, values);

      return await getLastInsert(swap.user_id, swap.bot_execution, swap.private_key, swap.token_symbol, swap.swap_type, swap.bot_type);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeStatus(id: number, status: number): Promise<void> {
    try {
      const sql = 'UPDATE swaps SET status = ?, updated_at = now() WHERE id = ?';
      const values = [status, id];

      await doQuery(sql, values);
      console.log(`[Swap] id ${id}, status changed to ${status}`);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async find(id: number, userId: number): Promise<Swap | null> {
    try {
      const sql = `
      SELECT *
      FROM swaps
      WHERE id = ?
      AND user_id = ?
      `;
      const values = [id, userId];

      const row: Swap | any = await doQuery(sql, values);
      const data: Swap = row[0];

      if (!data) {
        throw "Swap not find";
      }

      return data;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async list(userId: number, status: number = -1): Promise<Swap[]> {
    try {
      let sql = `
      SELECT *
      FROM swaps
      WHERE id > 0
      ${userId > 0 ? 'AND user_id = ?' : ''}
      ${status >= 0 ? 'AND status = ?' : ''}
      ORDER BY id DESC `;

      let values: any[] = [];

      if (userId > 0) {
        values.push(userId);
      }

      if (status >= 0) {
        values.push(status);
      }

      const list: any = await doQuery(sql, values);

      return list;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listToStart(): Promise<Swap[]> {
    try {
      let sql = `
      SELECT *
      FROM swaps
      WHERE id > 0
      AND status = 0
      AND mode = 'linear'
      ORDER BY id DESC
      `;

      const list: any = await doQuery(sql);

      return list;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listToStartIdles(botUuid: string, status: number = 0, userId: number = 0): Promise<Swap[]> {
    try {
      let sql = `
      SELECT *
      FROM swaps
      WHERE id > 0
      AND mode = 'queue'
      AND status = ?
      AND bot_uuid = ?
      ${userId > 0 ? 'AND user_id = ?' : ''}
      ORDER BY id DESC `;

      let values: any[] = [
        status,
        botUuid,
        userId
      ];

      const list: any = await doQuery(sql, values);

      return list;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async queueCount(botUuid: string): Promise<number> {
    try {
      const sql = `
      SELECT COUNT(*) AS queue
      FROM swaps
      WHERE bot_uuid = ?
      AND status = 0
      AND mode = 'queue'
      `;
      const values = [botUuid];

      const row: any = await doQuery(sql, values);
      const data = row[0];

      return data.queue;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
}

async function getLastInsert(userId: number, botExecution: number, privateKey: string, symbol: string, swap_type: string, bot_type: keyof BotExecution): Promise<Swap> {
  try {
    const sql = `
    SELECT *
    FROM swaps
    WHERE user_id = ?
    AND bot_execution = ?
    AND private_key = ?
    AND token_symbol = ?
    AND swap_type = ?
    AND bot_type = ?
    LIMIT 1
    `;
    const values = [userId, botExecution, privateKey, symbol, swap_type, bot_type];

    const row: Swap | any = await doQuery(sql, values);
    const data: Swap = row[0];

    if (!data) {
      throw "Swap last insert not find";
    }

    return data;
  } catch (err) {
    if (err instanceof Error) {
      console.log('SQL error', err.message);
      throw err.message;
    } else {
      console.log('SQL error', err);
      throw err;
    }
  }
}
