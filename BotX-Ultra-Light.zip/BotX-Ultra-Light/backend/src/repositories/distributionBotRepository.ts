import { decrypt, encrypt, setPage } from '../helpers/functionsHelper';
import { DistributionBot } from '../models/DistributionBot';
import { DistributionBotWallet } from '../models/DistributionBotWallet';
import { DistributionBotWalletRepository } from './distributionBotWalletRepository';
import { Transaction } from '../models/Transaction';
import { settings } from '../utils/settings';
import doQuery from '../utils/db';
import { getSigner } from '../helpers/ethersHelper';

export class DistributionBotRepository {
  async create(distributionBot: DistributionBot, wallets: DistributionBotWallet[]): Promise<void> {
    try {
      await getSigner(distributionBot.account_private_key);
      
      const encryptPrivateKey = encrypt(distributionBot.account_private_key);
      
      if (await verifyPrivateKeyExists(encryptPrivateKey)) {
        throw "This account private key already exists";
      }
      
      const sql = 'INSERT INTO distribution_bots (uuid, user_id, name, password, token_symbol, delay, account_private_key, account_friendly_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
      const values = [
        distributionBot.uuid,
        distributionBot.user_id,
        distributionBot.name,
        distributionBot.password,
        distributionBot.token_symbol,
        distributionBot.delay,
        encryptPrivateKey,
        distributionBot.account_friendly_name
      ];
      
      const sqlRow: any = await doQuery(sql, values);
      
      if (sqlRow.affectedRows > 0) {
        const distributionBotData: DistributionBot = await getLastInsert(distributionBot.user_id);
        
        if (distributionBotData) {
          const distributionBotWalletRepository = new DistributionBotWalletRepository();
          wallets.forEach(async element => {
            await distributionBotWalletRepository.create(element);
          });
        }
      }
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async update(distributionBot: DistributionBot, wallets: DistributionBotWallet[]): Promise<void> {
    try {
      let sql = 'UPDATE distribution_bots SET name = ?, token_symbol = ?, delay = ?, account_friendly_name = ?, updated_at = now() WHERE uuid = ? AND user_id = ?';
      let values = [
        distributionBot.name,
        distributionBot.token_symbol,
        distributionBot.delay,
        distributionBot.account_friendly_name,
        distributionBot.uuid,
        distributionBot.user_id
      ];
      
      if (distributionBot.password) {
        sql = 'UPDATE distribution_bots SET name = ?, password = ?, token_symbol = ?, delay = ?, account_friendly_name = ?, updated_at = now() WHERE uuid = ? AND user_id = ?';
        values = [
          distributionBot.name,
          distributionBot.password,
          distributionBot.token_symbol,
          distributionBot.delay,
          distributionBot.account_friendly_name,
          distributionBot.uuid,
          distributionBot.user_id
        ];
      }
      
      await doQuery(sql, values);
      
      const distributionBotWalletRepository = new DistributionBotWalletRepository();
      await distributionBotWalletRepository.verifyUpdateWallets(distributionBot.uuid, wallets);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async changeActive(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE distribution_bots SET active = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];
      
      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async find(userId: number, uuid: string): Promise<DistributionBot | null> {
    try {
      const sql = `SELECT * FROM distribution_bots WHERE uuid = ? AND user_id = ?`;
      const values = [uuid, userId];
      
      const distributionBotRow: DistributionBot | any = await doQuery(sql, values);
      const distributionBotData = distributionBotRow[0];
      
      if (distributionBotData) {
        const distributionBotWalletRepository = new DistributionBotWalletRepository();
        distributionBotData.wallets = await distributionBotWalletRepository.listSystem(uuid);
      }
      
      if (distributionBotData?.account_private_key) {
        distributionBotData.account_private_key = decrypt(distributionBotData.account_private_key);
      }
      
      return distributionBotData;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async list(userId: number): Promise<DistributionBot[]> {
    try {
      let sql = `
      SELECT distribution_bots.*,
      (SELECT COUNT(*) FROM bot_executions WHERE bot_executions.distribution_bot = distribution_bots.id) AS executions,
      COUNT(DISTINCT transactions.id) AS transactions
      FROM distribution_bots
      LEFT JOIN distribution_bot_wallets dbw ON distribution_bots.uuid = dbw.distribution_bot_uuid
      LEFT JOIN transactions ON dbw.id = transactions.distribution_bot_wallet
      WHERE distribution_bots.is_hidden = 0
      ${userId > 0 ? 'AND distribution_bots.user_id = ?' : ''}
      GROUP BY 
      distribution_bots.id,
      distribution_bots.uuid,
      distribution_bots.user_id,
      distribution_bots.name,
      distribution_bots.password,
      distribution_bots.token_symbol,
      distribution_bots.account_private_key,
      distribution_bots.account_friendly_name,
      distribution_bots.delay,
      distribution_bots.active,
      distribution_bots.is_hidden,
      distribution_bots.created_at,
      distribution_bots.updated_at
      ORDER BY distribution_bots.id DESC`;
      
      const values: any = [];
      
      if (userId > 0) {
        values.push(userId);
      }
      
      const listDistributionBots: DistributionBot[] | any = await doQuery(sql, values);
      
      const distributionBotWalletRepository = new DistributionBotWalletRepository();
      
      const promises = listDistributionBots.map(async (element: DistributionBot) => {
        if (element.account_private_key) {
          element.account_private_key = decrypt(element.account_private_key);
        }
        
        element.wallets = await distributionBotWalletRepository.list(element.uuid);
        return element;
      });
      
      const list = await Promise.all(promises);
      
      return list;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async listHidden(userId: number): Promise<DistributionBot[]> {
    try {
      let sql = `SELECT * FROM distribution_bots WHERE is_hidden = 1 ORDER BY id DESC`;
      const values: any = [];
      
      if (userId > 0) {
        sql = `SELECT * FROM distribution_bots WHERE user_id = ? AND is_hidden = 1 ORDER BY id DESC`;
        values.push(userId);
      }
      
      const listDistributionBots: DistributionBot[] | any = await doQuery(sql, values);
      
      const distributionBotWalletRepository = new DistributionBotWalletRepository();
      
      const promises = listDistributionBots.map(async (element: DistributionBot) => {
        if (element.account_private_key) {
          element.account_private_key = decrypt(element.account_private_key);
        }
        
        element.wallets = await distributionBotWalletRepository.list(element.uuid);
        return element;
      });
      
      const list = await Promise.all(promises);
      
      return list;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async listToStart(): Promise<DistributionBot[]> {
    try {
      let sql = `
      SELECT * 
      FROM distribution_bots 
      WHERE is_hidden = 0 
      AND active = 1`;
      
      const listDistributionBots: DistributionBot[] | any = await doQuery(sql);
      
      return listDistributionBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async isRunning(uuid: string): Promise<boolean> {
    try {
      const sql = 'SELECT * FROM distribution_bots WHERE uuid = ?';
      const values = [uuid];
      
      const botRow: DistributionBot | any = await doQuery(sql, values);
      const botData: DistributionBot = botRow[0];
      
      return botData.active;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async changeHidden(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE distribution_bots SET is_hidden = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];
      
      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async executionsDetails(distributionBotUuid: string, symbol: string, startDate: string, endDate: string): Promise<Transaction> {
    try {
      let sql = `SELECT 
      (
        SELECT ROUND((SUM(CASE WHEN t.status = 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS success_rate,
      (
        SELECT SUM(end_matic)
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND t.symbol_selected_token = 'MATIC'
        AND t.status = 1
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_output,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND t.symbol_selected_token != 'MATIC'
        AND t.symbol_selected_token != 'WMATIC'
        AND t.status = 1
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_output,
      (
        SELECT SUM(end_matic) 
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND new_wallet_private_key IS NOT NULL 
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.status = 0
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_fails,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.status = 0
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_fails
      FROM transactions t
      LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
      WHERE t.type = 'distribution'
      AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
      ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
      ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
      ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      `;
      
      const values: any[] = [];
      
      const details: Transaction | any = await doQuery(sql, values);
      
      return details[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async transactions(distributionBotUuid: string, executionId: number, page: number, symbol: string, startDate: string, endDate: string): Promise<Transaction[]> {
    try {
      let sql = `SELECT t.*
      FROM transactions t
      LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
      WHERE dbw.distribution_bot_uuid = ?
      AND t.bot_execution = ?`;
      
      const values: any[] = [distributionBotUuid, executionId];
      
      if (symbol) {
        sql += ` AND t.symbol_selected_token = ?`;
        values.push(symbol);
      }
      
      if (startDate) {
        sql += ` AND t.created_at >= ?`;
        values.push(startDate);
      }
      
      if (endDate) {
        sql += ` AND created_at <= ?`;
        values.push(endDate);
      }
      
      sql += ` ORDER BY t.id DESC LIMIT ? OFFSET ?`;
      values.push(settings.PAGE_SIZE, setPage(page));
      
      const listDistributionBotWallets: Transaction[] | any = await doQuery(sql, values);
      
      return listDistributionBotWallets;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
  
  async transactionsDetails(distributionBotUuid: string, executionId: number, symbol: string, startDate: string, endDate: string): Promise<any> {
    try {
      let sql = `SELECT 
      (
        SELECT ROUND((SUM(CASE WHEN t.status = 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS success_rate,
      (
        SELECT SUM(end_matic)
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND t.symbol_selected_token = 'MATIC'
        AND t.status = 1
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.bot_execution =${executionId}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_output,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND t.symbol_selected_token != 'MATIC'
        AND t.symbol_selected_token != 'WMATIC'
        AND t.status = 1
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_output,
      (
        SELECT SUM(end_matic) 
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND new_wallet_private_key IS NOT NULL 
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.status = 0
        AND t.bot_execution =${executionId}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_fails,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
        WHERE t.type = 'distribution'
        AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
        AND t.status = 0
        AND t.bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_fails
      FROM transactions t
      LEFT JOIN distribution_bot_wallets dbw ON t.distribution_bot_wallet = dbw.id
      WHERE t.type = 'distribution'
      AND dbw.distribution_bot_uuid = "${distributionBotUuid}"
      AND t.bot_execution =${executionId}
      ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
      ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
      ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      `;
      
      const values: any[] = [];
      
      const details: Transaction | any = await doQuery(sql, values);
      
      return details[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
}

async function getLastInsert(userId: number): Promise<DistributionBot> {
  try {
    const selectSql = 'SELECT * FROM distribution_bots WHERE user_id = ? ORDER BY id DESC LIMIT 1';
    const values = [userId];
    
    const botRow: DistributionBot | any = await doQuery(selectSql, values);
    const botData = botRow[0];
    
    if (botData.account_private_key) {
      botData.account_private_key = decrypt(botData.account_private_key);
    }
    
    return botData;
  } catch (err) {
    if (err instanceof Error) {
      console.log('SQL error', err.message);
      throw err.message;
    } else {
      console.log('SQL error', err);
      throw err;
    }
  }
}

async function verifyPrivateKeyExists(accountPrivateKey: string): Promise<DistributionBot | null> {
  try {
    const sql = `
    SELECT distribution_bots.id
    FROM distribution_bots
    WHERE account_private_key = ?
  `;
    
    const values = [accountPrivateKey];
    
    const distributionBotRow: DistributionBot | any = await doQuery(sql, values);
    const distributionBotData: DistributionBot = distributionBotRow[0];
    
    if (distributionBotData?.account_private_key) {
      distributionBotData.account_private_key = decrypt(distributionBotData.account_private_key);
    }
    
    return distributionBotData;
  } catch (err) {
    if (err instanceof Error) {
      throw err.message;
    } else {
      throw err;
    }
  }
}
