import { Transaction } from '../models/Transaction';
import { decrypt, encrypt, setPage } from '../helpers/functionsHelper';
import { VolumeBot } from '../models/VolumeBot';
import doQuery from '../utils/db';
import { settings } from '../utils/settings';
import { getSigner } from '../helpers/ethersHelper';

export class VolumeBotRepository {
  async create(volumeBot: VolumeBot): Promise<void> {
    try {
      if (volumeBot.account_private_key_buy === volumeBot.account_private_key_sell) {
        throw "The private keys must be different";
      }

      await getSigner(volumeBot.account_private_key_buy);
      await getSigner(volumeBot.account_private_key_sell);

      const encryptPrivateKeyBuy = encrypt(volumeBot.account_private_key_buy);

      if (await verifyPrivateKeyExists(encryptPrivateKeyBuy)) {
        throw "This account private key buy already exists";
      }

      const encryptPrivateKeySell = encrypt(volumeBot.account_private_key_sell);

      if (await verifyPrivateKeyExists(encryptPrivateKeySell)) {
        throw "This account private key sell already exists";
      }

      const sql = `
        INSERT INTO volume_bots (
        uuid, 
        user_id, 
        name, 
        min_amount,
        max_amount,
        min_delay, 
        max_delay,
        slippage_tolerance, 
        delay_to_start,
        airdrop_time,
        sell_swap_times,
        account_private_key_buy,
        account_private_key_sell,
        private_key_buy_friendly_name,
        private_key_sell_friendly_name,
        token_name,
        token_symbol,
        token_address
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const values = [
        volumeBot.uuid,
        volumeBot.user_id,
        volumeBot.name,
        volumeBot.min_amount,
        volumeBot.max_amount,
        volumeBot.min_delay,
        volumeBot.max_delay,
        volumeBot.slippage_tolerance,
        volumeBot.delay_to_start,
        volumeBot.airdrop_time,
        volumeBot.sell_swap_times,
        encryptPrivateKeyBuy,
        encryptPrivateKeySell,
        volumeBot.private_key_buy_friendly_name,
        volumeBot.private_key_sell_friendly_name,
        volumeBot.token_name,
        volumeBot.token_symbol,
        volumeBot.token_address
      ];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async update(volumeBot: VolumeBot): Promise<void> {
    try {
      const sql = `
        UPDATE volume_bots SET 
        name = ?, 
        min_amount = ?, 
        max_amount = ?, 
        min_delay = ?, 
        max_delay = ?, 
        sell_swap_times = ?,
        slippage_tolerance = ?, 
        delay_to_start = ?, 
        airdrop_time = ?,
        private_key_buy_friendly_name = ?,
        private_key_sell_friendly_name = ?,
        token_name = ?,
        token_symbol = ?,
        token_address = ?,
        updated_at = now() 
        WHERE uuid = ?
      `;
      
      const values = [
        volumeBot.name,
        volumeBot.min_amount,
        volumeBot.max_amount,
        volumeBot.min_delay,
        volumeBot.max_delay,
        volumeBot.sell_swap_times,
        volumeBot.slippage_tolerance,
        volumeBot.delay_to_start,
        volumeBot.airdrop_time,
        volumeBot.private_key_buy_friendly_name,
        volumeBot.private_key_sell_friendly_name,
        volumeBot.token_name,
        volumeBot.token_symbol,
        volumeBot.token_address,
        volumeBot.uuid
      ];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeActive(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE volume_bots SET active = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeAirdropActive(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE volume_bots SET active_airdrop = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeNeedWait(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE volume_bots SET need_wait = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async isRunning(uuid: string): Promise<boolean> {
    try {
      const sql = 'SELECT * FROM volume_bots WHERE uuid = ?';
      const values = [uuid];

      const volumeBotData: VolumeBot | any = await doQuery(sql, values);

      return volumeBotData[0].active;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async find(uuid: string, userId: number): Promise<VolumeBot | null> {
    try {
      const sql = `
      SELECT *
      FROM volume_bots
      WHERE uuid = ?
      AND user_id = ?
      `;
      const values = [uuid, userId];

      const volumeBotRow: VolumeBot | any = await doQuery(sql, values);
      const volumeBotData: VolumeBot = volumeBotRow[0];

      if (!volumeBotData) {
        throw "VolumeBot not find";
      }

      if (volumeBotData?.account_private_key_buy) {
        volumeBotData.account_private_key_buy = decrypt(volumeBotData.account_private_key_buy);
      }

      if (volumeBotData?.account_private_key_sell) {
        volumeBotData.account_private_key_sell = decrypt(volumeBotData.account_private_key_sell);
      }

      return volumeBotData;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async findActives(): Promise<VolumeBot[]> {
    try {
      const sql = `
      SELECT *
      FROM volume_bots
      WHERE active = 1
      `;

      const listVolumeBots: VolumeBot[] | any = await doQuery(sql, []);

      listVolumeBots.forEach((element: VolumeBot) => {
        if (element?.account_private_key_buy) {
          element.account_private_key_buy = decrypt(element.account_private_key_buy);
        }

        if (element?.account_private_key_sell) {
          element.account_private_key_sell = decrypt(element.account_private_key_sell);
        }
      });

      return listVolumeBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async list(userId: number): Promise<VolumeBot[]> {
    try {
      let sql = `
      SELECT *, 
      (SELECT COUNT(*) FROM transactions WHERE volume_bot = volume_bots.id) AS transactions,
      (SELECT COUNT(*) FROM bot_executions WHERE volume_bot = volume_bots.id) AS executions
      FROM volume_bots
      WHERE is_hidden = 0
      ${userId > 0 ? 'AND user_id = ?' : ''}
      ORDER BY id DESC `;
      let values: any[] = [];

      if (userId > 0) {
        values.push(userId);
      }

      const listVolumeBots: any = await doQuery(sql, values);

      listVolumeBots.forEach((element: VolumeBot) => {
        if (element?.account_private_key_buy) {
          element.account_private_key_buy = decrypt(element.account_private_key_buy);
        }

        if (element?.account_private_key_sell) {
          element.account_private_key_sell = decrypt(element.account_private_key_sell);
        }
      });

      return listVolumeBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listInactives(type: string = '', userId: number): Promise<VolumeBot[]> {
    try {
      let sql = `
      SELECT *
      FROM volume_bots
      WHERE is_hidden = 1
      ${userId > 0 ? 'AND user_id = ?' : ''}
      ORDER BY id DESC `;
      let values: any[] = [];

      if (userId > 0) {
        values.push(userId);
      }

      const listVolumeBots: any = await doQuery(sql, values);

      listVolumeBots.forEach((element: VolumeBot) => {
        if (element?.account_private_key_buy) {
          element.account_private_key_buy = decrypt(element.account_private_key_buy);
        }

        if (element?.account_private_key_sell) {
          element.account_private_key_sell = decrypt(element.account_private_key_sell);
        }
      });

      return listVolumeBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listToStart(): Promise<[]> {
    try {
      let sql = `
      SELECT volume_bots.id, volume_bots.active, volume_bots.user_id, volume_bots.uuid, bot_executions.id AS execution_id
      FROM volume_bots
      LEFT JOIN bot_executions ON bot_executions.volume_bot = volume_bots.id
      WHERE volume_bots.is_hidden = 0
      AND volume_bots.active = 1
      AND bot_executions.active = 1
      GROUP BY volume_bots.id, volume_bots.uuid, volume_bots.active, volume_bots.user_id, execution_id`;
      let values: any[] = [];

      const listVolumeBots: any = await doQuery(sql, values);

      return listVolumeBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listInactivesWithExecutionActive(): Promise<[]> {
    try {
      let values: any[] = [];

      let sql = `
      SELECT volume_bots.id, volume_bots.name, bot_executions.id AS execution_id
      FROM volume_bots
      LEFT JOIN bot_executions ON bot_executions.volume_bot = volume_bots.id
      WHERE volume_bots.is_hidden = 0
      AND volume_bots.active = 0
      AND bot_executions.active = 1
      GROUP BY volume_bots.id, volume_bots.name, execution_id`;

      const listVolumeBots: any = await doQuery(sql, values);

      return listVolumeBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeHidden(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE volume_bots SET is_hidden = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async executionsDetails(id: number, symbol: string, startDate: string, endDate: string): Promise<Transaction> {
    try {
      let sql = `SELECT 
      (
        SELECT ROUND((SUM(CASE WHEN t.status = 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
        FROM transactions t
        WHERE type != 'airdrop'
        AND volume_bot = ${id}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS success_rate,
      (
        SELECT SUM(end_matic)
        FROM transactions t
        WHERE type = 'transfer_start'
        AND symbol_selected_token = 'MATIC'
        AND status = 1
        AND volume_bot = ${id}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_output,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        WHERE type = 'transfer_start'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND volume_bot = ${id}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_output,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny'
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        AND status = 1
        AND volume_bot = ${id}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_input,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND volume_bot = ${id}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_input,
      (
        ${!symbol ? `SELECT FORMAT(COUNT(id) / 2, 0)` : 'SELECT FORMAT(COUNT(id), 0)'}
        FROM transactions t
        WHERE (type = 'transfer' OR type = 'transfer_start')
        AND volume_bot = ${id}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS ghost_wallets,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND status = 1
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_success,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND status = 0
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_fails,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_success,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND status = 0
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_fails,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_pending,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_pending
      FROM transactions
      LEFT JOIN volume_bots ON transactions.volume_bot = volume_bots.id
      WHERE transactions.type != 'airdrop' 
      AND transactions.new_wallet_private_key IS NOT NULL 
      AND transactions.volume_bot = ${id}
      ${symbol ? `AND transactions.symbol_selected_token = "${symbol}"` : ''}
      ${startDate ? `AND transactions.created_at >= "${startDate}"` : ''}
      ${endDate ? `AND transactions.created_at <= "${endDate}"` : ''}
      `;

      const values: any[] = [];

      const details: Transaction | any = await doQuery(sql, values);

      return details[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async transactions(volumeBotId: number, executionId: number, page: number, symbol: string, startDate: string, endDate: string): Promise<Transaction[]> {
    try {
      let sql = `SELECT *
      FROM transactions 
      WHERE volume_bot = ? 
      AND bot_execution = ?
      AND type != 'airdrop'`;

      const values: any[] = [volumeBotId, executionId];

      if (symbol) {
        sql += ` AND symbol_selected_token = ?`;
        values.push(symbol);
      }

      if (startDate) {
        sql += ` AND created_at >= ?`;
        values.push(startDate);
      }

      if (endDate) {
        sql += ` AND created_at <= ?`;
        values.push(endDate);
      }

      sql += ` ORDER BY id DESC LIMIT ? OFFSET ?`;
      values.push(settings.PAGE_SIZE, setPage(page));

      const listDistributionVolumeBotWallets: Transaction[] | any = await doQuery(sql, values);

      return listDistributionVolumeBotWallets;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async transactionsDetails(id: number, executionId: number, symbol: string, startDate: string, endDate: string): Promise<Transaction> {
    try {
      let sql = `SELECT 
      (
        SELECT ROUND((SUM(CASE WHEN t.status = 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
        FROM transactions t
        WHERE type != 'airdrop'
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS success_rate,
      (
        SELECT SUM(end_matic)
        FROM transactions t
        WHERE type = 'transfer_start'
        AND symbol_selected_token = 'MATIC'
        AND status = 1
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_output,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        WHERE type = 'transfer_start'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_output,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny'
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        AND status = 1
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_input,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_input,
      (
        
        ${!symbol ? `SELECT FORMAT(COUNT(id) / 2, 0)` : 'SELECT FORMAT(COUNT(id), 0)'}
        FROM transactions t
        WHERE (type = 'transfer' OR type = 'transfer_start')
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS ghost_wallets,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 1
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_success,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 0
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_fails,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_success,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 0
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_fails,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_pending,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND volume_bot = ${id}
        AND bot_execution =${executionId}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_pending
      FROM transactions t
      LEFT JOIN volume_bots ON t.volume_bot = volume_bots.id
      WHERE t.type != 'airdrop' 
      AND t.new_wallet_private_key IS NOT NULL 
      AND t.volume_bot = ${id}
      AND t.bot_execution =${executionId}
      ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
      ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
      ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      `;

      const values: any[] = [];

      const details: Transaction | any = await doQuery(sql, values);

      return details[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
}

async function verifyPrivateKeyExists(accountPrivateKey: string): Promise<boolean> {
  try {
    const sql = `
    SELECT id
    FROM volume_bots
    WHERE account_private_key_buy = ?
    OR account_private_key_sell = ?
    `;

    const values = [accountPrivateKey, accountPrivateKey];

    const botRow: VolumeBot | any = await doQuery(sql, values);
    const botData: VolumeBot = botRow[0];

    if (botData) {
      return true;
    }

    return false;
  } catch (err) {
    if (err instanceof Error) {
      throw err.message;
    } else {
      throw err;
    }
  }
}
