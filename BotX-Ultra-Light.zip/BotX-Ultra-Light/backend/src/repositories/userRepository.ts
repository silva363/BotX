import doQuery from '../utils/db';

export class UserRepository {
  async findByWallet(wallet: string): Promise<any> {
    try {
      const sql = `
      SELECT * FROM users WHERE wallet_address = ? LIMIT 1
      `;
      const values = [wallet];

      const userRow:  any = await doQuery(sql, values);
      const userData = userRow[0];

      return userData;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
}