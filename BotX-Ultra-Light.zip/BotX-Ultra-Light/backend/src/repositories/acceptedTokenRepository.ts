import { AcceptedToken } from '../models/AcceptedToken';
import doQuery from '../utils/db';

export class AcceptedTokenRepository {
  async create(acceptedToken: AcceptedToken): Promise<void> {
    try {
      const sql = 'INSERT INTO accepted_tokens (name, symbol, address, decimals, pool_address, pool_name, pool_symbol, pool_decimals) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
      const values = [
        acceptedToken.name,
        acceptedToken.symbol,
        acceptedToken.address,
        acceptedToken.decimals,
        acceptedToken.pool_address,
        acceptedToken.pool_name,
        acceptedToken.pool_symbol,
        acceptedToken.pool_decimals,
      ];
      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async update(acceptedToken: AcceptedToken): Promise<void> {
    try {
      const sql = 'UPDATE accepted_tokens SET name = ?, symbol = ?, address = ?, decimals = ?, pool_address = ?, pool_name = ?, pool_symbol = ?, pool_decimals = ?, updated_at = now() WHERE id = ?';
      const values = [
        acceptedToken.name,
        acceptedToken.symbol,
        acceptedToken.address,
        acceptedToken.decimals,
        acceptedToken.pool_address,
        acceptedToken.pool_name,
        acceptedToken.pool_symbol,
        acceptedToken.pool_decimals,
        acceptedToken.id
      ];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeActive(id: number, active: boolean): Promise<void> {
    try {
      const sql = 'UPDATE accepted_tokens SET active = ?, updated_at = now() WHERE id = ?';
      const values = [active, id];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async findByAddress(address: string): Promise<AcceptedToken | null> {
    try {
      const sql = 'SELECT * FROM accepted_tokens WHERE LOWER(address) = LOWER(?)';
      const values = [address];

      const tokenData: AcceptedToken | any = await doQuery(sql, values);

      return tokenData[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async findBySymbol(symbol: string): Promise<AcceptedToken> {
    try {
      const sql = 'SELECT * FROM accepted_tokens WHERE symbol = ?';
      const values = [symbol];

      const tokenData: AcceptedToken | any = await doQuery(sql, values);

      return tokenData[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async findById(id: number): Promise<AcceptedToken> {
    try {
      const sql = 'SELECT * FROM accepted_tokens WHERE id = ?';
      const values = [id];

      const tokenData: AcceptedToken | any = await doQuery(sql, values);

      return tokenData[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async list(): Promise<AcceptedToken[]> {
    try {
      const sql = `
      SELECT * FROM accepted_tokens ORDER BY id DESC`;

      const listTokens: AcceptedToken[] | any = await doQuery(sql);

      return listTokens;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
}
