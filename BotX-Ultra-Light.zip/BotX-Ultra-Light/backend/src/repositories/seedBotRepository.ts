import { Transaction } from '../models/Transaction';
import { decrypt, encrypt, setPage } from '../helpers/functionsHelper';
import { SeedBot } from '../models/SeedBot';
import doQuery from '../utils/db';
import { settings } from '../utils/settings';
import { getSigner } from '../helpers/ethersHelper';

export class SeedBotRepository {
  async create(seedBot: SeedBot): Promise<void> {
    try {
      await getSigner(seedBot.account_private_key);

      const encryptPrivateKey = encrypt(seedBot.account_private_key);

      if (await verifyPrivateKeyExists(encryptPrivateKey)) {
        throw "This account private key already exists";
      }

      const encryptHelperPrivateKey = encrypt(seedBot.helper_private_key);

      const sql = `
      INSERT INTO seed_bots 
      (uuid, user_id, name, helper_private_key, account_private_key, account_friendly_name, destiny_address, destiny_friendly_name, token_symbol, token_name, token_address, amount, cycles, cycle_ghosts, cycle_delay, airdrop_time) 
      VALUES 
      (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const values = [
        seedBot.uuid,
        seedBot.user_id,
        seedBot.name,
        encryptHelperPrivateKey,
        encryptPrivateKey,
        seedBot.account_friendly_name,
        seedBot.destiny_address,
        seedBot.destiny_friendly_name,
        seedBot.token_symbol,
        seedBot.token_name,
        seedBot.token_address,
        seedBot.amount,
        seedBot.cycles,
        seedBot.cycle_ghosts,
        seedBot.cycle_delay,
        seedBot.airdrop_time
      ];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async update(seedBot: SeedBot): Promise<void> {

    try {
      let addEncryptPrivateKey = '';

      if (seedBot.account_private_key) {
        const encryptPrivateKey = encrypt(seedBot.account_private_key);

        if (await verifyPrivateKeyExists(encryptPrivateKey)) {
          throw "This account private key already exists";
        }

        addEncryptPrivateKey = `, account_private_key = "${encryptPrivateKey}"`;
      };

      let sql = `
      UPDATE seed_bots 
      SET name = ?, account_friendly_name = ?, destiny_address = ?, destiny_friendly_name = ?, 
      token_symbol = ?, token_name = ?, token_address = ?, amount = ?, 
      cycles = ?, cycle_ghosts = ?, cycle_delay = ?, airdrop_time = ?, 
      updated_at = now() ${addEncryptPrivateKey}
      WHERE uuid = ?`;
      const values = [
        seedBot.name,
        seedBot.account_friendly_name,
        seedBot.destiny_address,
        seedBot.destiny_friendly_name,
        seedBot.token_symbol,
        seedBot.token_name,
        seedBot.token_address,
        seedBot.amount,
        seedBot.cycles,
        seedBot.cycle_ghosts,
        seedBot.cycle_delay,
        seedBot.airdrop_time,
        seedBot.uuid
      ];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async updateActualCycle(id: number, cycle: number): Promise<void> {
    try {
      let sql = `
      UPDATE seed_bots 
      SET actual_cycle = ?,
      updated_at = now()
      WHERE id = ?`;
      const values = [
        cycle,
        id
      ];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeActive(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE seed_bots SET active = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async find(uuid: string, userId: number): Promise<SeedBot> {
    try {
      const sql = `
      SELECT *
      FROM seed_bots
      WHERE uuid = ?
      AND user_id = ?
      `;
      const values = [uuid, userId];

      const botRow: SeedBot | any = await doQuery(sql, values);
      const botData: SeedBot = botRow[0];

      if (!botData) {
        throw "Seed bot not find";
      }

      if (botData?.account_private_key) {
        botData.account_private_key = decrypt(botData.account_private_key);
      }

      if (botData?.helper_private_key) {
        botData.helper_private_key = decrypt(botData.helper_private_key);
      }

      return botData;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async list(userId: number): Promise<SeedBot[]> {
    try {
      let sql = `
      SELECT *, 
      0 AS transactions, 
      0 AS executions
      FROM seed_bots 
      WHERE is_hidden = 0 
      ${userId > 0 ? 'AND user_id = ?' : ''}
      ORDER BY id DESC`;
      const values: any = [];

      if (userId > 0) {
        values.push(userId);
      }

      const listBots: any = await doQuery(sql, values);

      listBots.forEach((element: SeedBot) => {
        if (element.account_private_key) {
          element.account_private_key = decrypt(element.account_private_key);
        }

        if (element?.helper_private_key) {
          element.helper_private_key = decrypt(element.helper_private_key);
        }
      });

      return listBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listInactives(userId: number): Promise<SeedBot[]> {
    try {
      const sql = `
      SELECT *
      FROM seed_bots
      WHERE is_hidden = 1
      AND user_id = ?
      ORDER BY id DESC `;

      const values: any[] = [userId];

      const listBots: any = await doQuery(sql, values);

      listBots.forEach((element: SeedBot) => {
        if (element.account_private_key) {
          element.account_private_key = decrypt(element.account_private_key);
        }
      });

      return listBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async listToStart(): Promise<SeedBot[]> {
    try {
      let sql = `
      SELECT seed_bots.*, bot_executions.id AS execution_id
      FROM seed_bots 
      LEFT JOIN bot_executions ON bot_executions.seed_bot = seed_bots.id
      WHERE seed_bots.is_hidden = 0 
      AND seed_bots.active = 1
      AND bot_executions.active IN (1,2)
      GROUP BY    
      seed_bots.id, 
      seed_bots.uuid, 
      seed_bots.user_id, 
      seed_bots.name, 
      seed_bots.account_private_key, 
      seed_bots.account_friendly_name, 
      seed_bots.destiny_address, 
      seed_bots.destiny_friendly_name, 
      seed_bots.token_name, 
      seed_bots.token_symbol, 
      seed_bots.token_address, 
      seed_bots.amount, 
      seed_bots.cycles, 
      seed_bots.cycle_ghosts, 
      seed_bots.cycle_delay, 
      seed_bots.airdrop_time, 
      seed_bots.active, 
      seed_bots.is_hidden, 
      seed_bots.created_at, 
      seed_bots.updated_at,
      execution_id`;

      const listBots: any = await doQuery(sql);

      listBots.forEach((element: SeedBot) => {
        if (element.account_private_key) {
          element.account_private_key = decrypt(element.account_private_key);
        }
      });

      return listBots;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async changeHidden(uuid: string, active: number): Promise<void> {
    try {
      const sql = 'UPDATE seed_bots SET is_hidden = ?, updated_at = now() WHERE uuid = ?';
      const values = [active, uuid];

      await doQuery(sql, values);
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async executionsDetails(id: number, symbol: string, startDate: string, endDate: string): Promise<Transaction> {
    try {
      let sql = `SELECT 
      (
        SELECT ROUND((SUM(CASE WHEN t.status = 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
        FROM transactions t
        WHERE type != 'airdrop'
        AND seed_bot = ${id}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS success_rate,
      (
        SELECT SUM(end_matic)
        FROM transactions t
        WHERE type = 'transfer_seed_start'
        AND symbol_selected_token = 'MATIC'
        AND status = 1
        AND seed_bot = ${id}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_output,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        WHERE type = 'transfer_seed_start'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND seed_bot = ${id}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_output,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny_seed'
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        AND status = 1
        AND seed_bot = ${id}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_input,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny_seed'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND seed_bot = ${id}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_input,
      (
        ${!symbol ? `SELECT FORMAT(COUNT(id) / 2, 0)` : 'SELECT FORMAT(COUNT(id), 0)'}
        FROM transactions t
        WHERE (type = 'transfer_seed' OR type = 'transfer_seed_start')
        AND seed_bot = ${id}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS ghost_wallets,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND status = 1
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_success,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND status = 0
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_fails,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_success,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND status = 0
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_fails,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_pending,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_pending
      FROM transactions
      LEFT JOIN seed_bots ON transactions.seed_bot = seed_bots.id
      WHERE transactions.type != 'airdrop' 
      AND transactions.new_wallet_private_key IS NOT NULL 
      AND transactions.seed_bot = ${id}
      ${symbol ? `AND transactions.symbol_selected_token = "${symbol}"` : ''}
      ${startDate ? `AND transactions.created_at >= "${startDate}"` : ''}
      ${endDate ? `AND transactions.created_at <= "${endDate}"` : ''}
      `;

      const values: any[] = [];

      const details: Transaction | any = await doQuery(sql, values);

      return details[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async transactions(id: number, executionId: number, page: number, symbol: string, startDate: string, endDate: string): Promise<Transaction[]> {
    try {
      let sql = `SELECT *
      FROM transactions 
      WHERE seed_bot = ?
      AND bot_execution = ?`;

      const values: any[] = [id, executionId];

      if (symbol) {
        sql += ` AND symbol_selected_token = ?`;
        values.push(symbol);
      }

      if (startDate) {
        sql += ` AND created_at >= ?`;
        values.push(startDate);
      }

      if (endDate) {
        sql += ` AND created_at <= ?`;
        values.push(endDate);
      }

      sql += ` ORDER BY id DESC LIMIT ? OFFSET ?`;
      values.push(settings.PAGE_SIZE, setPage(page));

      const listDistributionBotWallets: Transaction[] | any = await doQuery(sql, values);

      return listDistributionBotWallets;
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }

  async transactionsDetails(id: number, executionId: number, symbol: string, startDate: string, endDate: string): Promise<Transaction> {
    try {
      let sql = `SELECT 
      (
        SELECT ROUND((SUM(CASE WHEN t.status = 1 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2)
        FROM transactions t
        WHERE type != 'airdrop'
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS success_rate,
      (
        SELECT SUM(end_matic)
        FROM transactions t
        WHERE type = 'transfer_seed_start'
        AND symbol_selected_token = 'MATIC'
        AND status = 1
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_output,
      (
        SELECT SUM(end_selected_token) 
        FROM transactions t
        WHERE type = 'transfer_seed_start'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_output,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny_seed'
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        AND status = 1
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_input,
      (
        SELECT SUM(start_selected_token) - SUM(end_selected_token)
        FROM transactions t
        WHERE type = 'transfer_destiny_seed'
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        AND status = 1
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_input,
      (
        
        ${!symbol ? `SELECT FORMAT(COUNT(id) / 2, 0)` : 'SELECT FORMAT(COUNT(id), 0)'}
        FROM transactions t
        WHERE (type = 'transfer_seed' OR type = 'transfer_seed_start')
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS ghost_wallets,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 1
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_success,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 0
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_fails,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 1
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_success,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND status = 0
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_fails,
      (
        SELECT SUM(end_matic) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND (symbol_selected_token = 'MATIC' OR symbol_selected_token = 'WMATIC')
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS matic_pending,
      (
        SELECT SUM(end_selected_token) FROM transactions t
        WHERE type != 'airdrop' 
        AND new_wallet_private_key IS NOT NULL 
        AND seed_bot = ${id}
        AND bot_execution =${executionId}
        AND need_airdrop = 1
        AND airdrop_status = 0
        AND status = 1
        AND symbol_selected_token != 'MATIC'
        AND symbol_selected_token != 'WMATIC'
        ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
        ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
        ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      ) AS selected_token_pending
      FROM transactions t
      LEFT JOIN seed_bots ON t.seed_bot = seed_bots.id
      WHERE t.type != 'airdrop' 
      AND t.new_wallet_private_key IS NOT NULL 
      AND t.seed_bot = ${id}
      AND t.bot_execution =${executionId}
      ${symbol ? `AND t.symbol_selected_token = "${symbol}"` : ''}
      ${startDate ? `AND t.created_at >= "${startDate}"` : ''}
      ${endDate ? `AND t.created_at <= "${endDate}"` : ''}
      `;

      const values: any[] = [];

      const details: Transaction | any = await doQuery(sql, values);

      return details[0];
    } catch (err) {
      if (err instanceof Error) {
        console.log('SQL error', err.message);
        throw err.message;
      } else {
        console.log('SQL error', err);
        throw err;
      }
    }
  }
}

async function verifyPrivateKeyExists(accountPrivateKey: string): Promise<SeedBot | null> {
  try {
    const sql = `
    SELECT id
    FROM seed_bots
    WHERE account_private_key = ?
    `;

    const values = [accountPrivateKey];

    const botRow: SeedBot | any = await doQuery(sql, values);
    const botData: SeedBot = botRow[0];

    if (botData?.account_private_key) {
      botData.account_private_key = decrypt(botData.account_private_key);
    }

    return botData;
  } catch (err) {
    if (err instanceof Error) {
      throw err.message;
    } else {
      throw err;
    }
  }
}
