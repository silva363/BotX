
import { settings } from "../utils/settings";
import { ethers } from 'ethers'

class BlockchainHelper {
    public usage = 0;

    getProvider(): ethers.JsonRpcProvider {
        try {
            const network = new ethers.Network('mainnet', settings.CHAIN_ID);
            const provider = new ethers.JsonRpcProvider(settings.ALCHEMY_API, network, {
                staticNetwork: network,
            });

            return provider;
        } catch (error) {
            console.log('[BlockchainHelper] getProvider error', error);
            throw error;
        }
    }
}

export default BlockchainHelper;