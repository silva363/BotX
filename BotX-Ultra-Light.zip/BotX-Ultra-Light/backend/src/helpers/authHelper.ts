import { getTimestampOnChain } from "../utils/data";
import { encryptSignature } from "./functionsHelper";
import { settings } from "../utils/settings";
import { Request } from "express";
import jwt from "jsonwebtoken";
import { UserRepository } from "../repositories/userRepository";

class AuthHelper {
  async getSignMessage() {
    try {
      const timestamp = await getTimestampOnChain();
      const encrypted = encryptSignature(JSON.stringify({ timestamp }));

      return ({ message: encrypted });
    } catch (e) {
      console.log(e);
      return ("An error ocurred");
    }
  }

  async getUserId(req: Request): Promise<number> {
    const token = req.header("authtoken")?.replace(" ", "");

    return new Promise((resolve, reject) => {
      jwt.verify(token!, settings.JWT_SECRET_KEY, async (err, decoded: any) => {
        if (err) {
          reject(err);
          return;
        }

        const signWallet = decoded.signWallet;
        const userRepository = new UserRepository();
        const userData = await userRepository.findByWallet(signWallet);

        resolve(Number(userData.id));
      });
    });
  }

}

export default AuthHelper;
