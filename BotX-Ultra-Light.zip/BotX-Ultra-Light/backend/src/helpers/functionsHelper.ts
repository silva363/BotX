import { TradeBot } from "../models/TradeBot";
import { TradeBotRepository } from "../repositories/tradeBotRepository";
import crypto from 'crypto';
import { promisify } from "util";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { settings } from "../utils/settings";
import { ethers } from "ethers";
import { VolumeBot } from "../models/VolumeBot";
import { VolumeBotRepository } from "../repositories/volumeBotRepository";
import { BotExecution } from "../models/BotExecution";
import { BotExecutionRepository } from "../repositories/botExecutionRepository";
import { TransactionRepository } from "../repositories/transactionRepository";
import { Transaction } from "../models/Transaction";
import { TradeBotService } from "../services/tradeBotService";

const scryptAsync = promisify(scrypt);

export function getTokenRange(min: number, max: number, decimalPlaces: number = 18, retry: number = 0): bigint {
    try {
        const range = Math.random() * (max - min) + min;
        const roundedRange = Number(range.toFixed(decimalPlaces));

        const finalValue = ethers.parseUnits(roundedRange.toString(), decimalPlaces);

        if (retry > 10) {
            throw 'getTokenRange error: more than 10 retries';
        }

        if (typeof finalValue !== 'bigint' || finalValue < 0) {
            console.log('getTokenRange retry');
            getTokenRange(min, max, decimalPlaces, retry + 1);
        }

        return finalValue;
    } catch (error) {
        if (error instanceof Error) {
            throw error.message;
        } else {
            throw error;
        }
    }
}

export function betweenFloat(begin: number, end: number, retry: number = 0): bigint {
    try {
        let max = end;
        let min = begin;
        let randNumber = Math.random() * (max - min) + min

        const finalValue = ethers.parseEther(randNumber.toString());

        if (retry > 10) {
            throw 'getTokenRange error: more than 10 retries';
        }

        if (typeof finalValue !== 'bigint' || finalValue < 0) {
            console.log('betweenFloat retry');
            betweenFloat(begin, end, retry + 1);
        }

        return finalValue;
    } catch (error) {
        if (error instanceof Error) {
            throw error.message;
        } else {
            throw error;
        }
    }
}

export async function getRange(min: number, max: number): Promise<number> {
    try {
        const range = Math.floor(Math.random() * (max - min + 1)) + min;
        return range;
    } catch (error) {
        if (error instanceof Error) {
            throw error.message;
        } else {
            throw error;
        }
    }
}

export async function countDecimals(x: number): Promise<number> {
    if (Math.floor(x) === x) {
        return 0
    }
    return x.toString().split('.')[1].length || 0
}

export function returnValidJson(isJson: string): string {
    try {
        JSON.parse(isJson);
        return isJson;
    } catch (e) {
        return JSON.stringify(isJson);
    }
}

export function isHolderTargetPercentage(actualBalance: number, percentage: number, initialBalance: number) {
    const equivalentValue = (percentage / 100) * initialBalance;
    return actualBalance < equivalentValue;
}

export async function removeFromList(list: TradeBot[], uuid: string) {
    const tradeBotRepository = new TradeBotRepository();
    await tradeBotRepository.changeActive(uuid, 0);

    const index = list.findIndex((listData) => listData.uuid === uuid);

    if (index !== -1) {
        list.splice(index, 1);
    }

    new TradeBotService().removeFromQueueList(uuid);
}

export async function removeVolumeBotFromList(list: VolumeBot[], uuid: string) {
    const volumeBotRepository = new VolumeBotRepository();
    await volumeBotRepository.changeActive(uuid, 0);

    const index = list.findIndex((listData) => listData.uuid === uuid);

    if (index !== -1) {
        list.splice(index, 1);
    }
}

export function hideCharacters(str: string, quant: number): string {
    if (str.length < quant) {
        return str;
    }

    const first = str.substring(0, quant);
    const last = str.substring(str.length - quant);

    let middle = str.length - quant;

    if (middle > 10) {
        middle = 10;
    }

    const middleStars = '*'.repeat(middle);

    return first + middleStars + last;
}

export function encrypt(data: string): string {
    try {
        const secretKey = Buffer.from(settings.ENCRYPT_32BIT_KEY, 'hex');
        const iv = Buffer.from(settings.ENCRYPT_16BIT_IV_KEY, 'hex');
        const cipher = crypto.createCipheriv('aes-256-cbc', secretKey, iv);

        let encryptedData = cipher.update(data, 'utf-8', 'hex');
        encryptedData += cipher.final('hex');

        return encryptedData;
    } catch (error) {
        console.log('encrypt error');
        return data;
    }
}

export function decrypt(data: string): string {
    try {
        if (data.length > 64) {
            const secretKey = Buffer.from(settings.ENCRYPT_32BIT_KEY, 'hex');
            const iv = Buffer.from(settings.ENCRYPT_16BIT_IV_KEY, 'hex');
            const decipher = crypto.createDecipheriv('aes-256-cbc', secretKey, iv);

            let decryptedData = decipher.update(data, 'hex', 'utf-8');
            decryptedData += decipher.final('utf-8');

            return decryptedData;
        }

        return data;
    } catch (error) {
        console.log('decrypt error', error);
        return data;
    }
}

export function encryptSignature(message: string) {
    try {
        const cipher = crypto.createCipheriv(
            'aes-128-ecb',
            Buffer.from(`${settings.SECRET_KEY}`, 'utf8'),
            null,
        );

        let encrypted = cipher.update(JSON.stringify(message), 'utf8', 'base64');
        encrypted += cipher.final('base64');

        return encrypted;
    } catch (error) {
        console.log('encryptSignature error');
        return message;
    }
}

export function decryptSignature(data: string): string {
    try {
        const source = Buffer.from(data, 'base64');
        const decipher = crypto.createDecipheriv('aes-128-ecb', settings.SECRET_KEY, null);

        const decrypted = Buffer.concat([
            decipher.update(source),
            decipher.final(),
        ]);

        return decrypted.toString('utf8');
    } catch (error) {
        console.log('decryptSignature error', error);
        return data;
    }
}

export async function timerCountdown(time: number, message: string, isMinutes: boolean) {
    switch (isMinutes) {
        case true:
            if (time % 10 != 0 || time > 1) {
                console.log(`${message} in ${time} minutes...`);
            }

            countMinutes(time, message);
            break;
        default:
            if (time > 0 && time < 60) {
                if (time != 10 && time > 1) {
                    console.log(`${message} in ${time} seconds...`);
                }

                countSeconds(time, message);
            } else {
                const minutes = Math.floor(time / 60);

                if (minutes % 10 != 0 && minutes > 1) {
                    console.log(`${message} in ${minutes} minutes...`);
                }

                countMinutes(minutes, message);
            }
            break;
    }
}

export function removePercent(amount: bigint, percentToReduce: number) {
    if (percentToReduce === 0) {
        return amount;
    }

    const reducePercent = 100 - percentToReduce;
    const newAmount = amount * BigInt(reducePercent) / BigInt(100);

    return newAmount;
}

export function calcPercent(amount: number, percentToCalc: number, decimals: number) {
    if (typeof amount !== 'number' || typeof percentToCalc !== 'number') {
        throw new Error('O valor e a porcentagem devem ser números.');
    }

    const finalValue = (amount * percentToCalc) / 100;

    return finalValue.toFixed(decimals);
}

export async function hashPassword(password: string) {
    const salt = randomBytes(16).toString("hex");
    const buf = (await scryptAsync(password, salt, 64)) as Buffer;
    return `${buf.toString("hex")}.${salt}`;
}

export async function comparePassword(
    storedPassword: string,
    suppliedPassword: string
): Promise<boolean> {
    const [hashedPassword, salt] = storedPassword.split(".");
    const hashedPasswordBuf = Buffer.from(hashedPassword, "hex");
    const suppliedPasswordBuf = (await scryptAsync(suppliedPassword, salt, 64)) as Buffer;
    return timingSafeEqual(hashedPasswordBuf, suppliedPasswordBuf);
}

export function setPage(page: number): number {
    const finalPage = (page - 1) * settings.PAGE_SIZE;

    return finalPage;
}

export function isTimeDifferenceGreaterThanMinutes(dateString: string): number {
    const specifiedDate = new Date(dateString);
    const currentDate = new Date();

    const differenceInMilliseconds = currentDate.getTime() - specifiedDate.getTime();

    return differenceInMilliseconds;
}

export async function calcStartTime(
    type: string,
    botName: string,
    botId: number,
    executionType: keyof BotExecution,
    txBotId: number,
    transactionType: keyof Transaction,
    startDelay: number,
    minDelay: number,
    maxDelay: number,
    isNewExecution: boolean
): Promise<{ delay: number, message: string }> {
    let isMinutes = true;
    let delay = startDelay! * 60000;
    let secondsDelay = 0;

    if (!isNewExecution) {
        const botExecutionRepository = new BotExecutionRepository();
        const havePendingExecution = await botExecutionRepository.havePendingExecution(botId, executionType);

        if (havePendingExecution) {
            const transactionRepository = new TransactionRepository();
            const lastTimeExecution = await transactionRepository.lastTransactionByExecutionId(havePendingExecution, txBotId, transactionType);

            if (lastTimeExecution) {
                const delayRange = await getRange(minDelay, maxDelay);
                const timeDifferenceDelay = delayRange - (isTimeDifferenceGreaterThanMinutes(lastTimeExecution) / 1000);

                delay = 0;

                if (timeDifferenceDelay > 0) {
                    secondsDelay = Number(timeDifferenceDelay.toFixed(0));
                    delay = secondsDelay * 1000;
                    isMinutes = false;
                }
            }
        }
    }

    let returnMessage = `[${type}] ${botName} running`;

    if (delay > 0) {
        const message = `[${type}] ${botName} will start`;
        if (isMinutes) {
            returnMessage = `${message} in ${startDelay} minutes`;
            countMinutes(startDelay, message);
        } else {
            returnMessage = `${message} in ${secondsDelay} seconds`;
            countSeconds(secondsDelay, message);
        }
    }

    return { delay: delay, message: returnMessage };
}

export function distributeTotalAmount(totalAmount: number, distributionTimes: number, attempt: number = 0): number[] {
    try {
        if (attempt > 30) {
            throw 'Failed to distribute total amount after 10 attempts';
        }

        const baseAmount = totalAmount / distributionTimes;
        const amounts = [];

        for (let i = 0; i < distributionTimes; i++) {
            const minVariation = 0.05 * baseAmount;
            const maxVariation = 0.20 * baseAmount;
            const variation = Math.random() * (maxVariation - minVariation) + minVariation;
            const amount = Math.random() < 0.5 ? baseAmount - variation : baseAmount + variation;
            amounts.push(amount);
        }

        let sum = amounts.reduce((acc, curr) => acc + curr, 0);
        let adjustmentFactor = totalAmount / sum;

        for (let i = 0; i < amounts.length; i++) {
            amounts[i] *= adjustmentFactor;
        }

        const uniqueAmounts = new Set(amounts);
        if (uniqueAmounts.size !== amounts.length) {
            console.log('Recalculating...');
            return distributeTotalAmount(totalAmount, distributionTimes, attempt + 1);
        }

        let finalSum = 0;
        amounts.forEach(amount => {
            finalSum += amount;
        });

        if (finalSum !== totalAmount) {
            console.log('Recalculating...');
            return distributeTotalAmount(totalAmount, distributionTimes, attempt + 1);
        }

        return amounts;
    } catch (error) {
        if (error instanceof Error) {
            throw error.message;
        } else {
            throw error;
        }
    }
}

async function countSeconds(seconds: number, message: string) {
    seconds--;

    if (seconds > 0) {
        if (seconds === 10) {
            console.log(`${message} in ${seconds} seconds...`);
        }

        setTimeout(() => {
            countSeconds(seconds, message);
        }, 1000);
    }
}

async function countMinutes(minutes: number, message: string) {
    if (minutes > 0) {
        if (minutes % 10 === 0 || minutes === 1) {
            console.log(`${message} in ${minutes} minutes...`);
        }

        setTimeout(() => {
            countMinutes(minutes, message);
        }, 60000);
    }

    minutes--;
}

export function perAmount(amount: bigint, per: number): bigint[] {
    const partes: bigint[] = [];
    let somaPartes = 0n;

    for (let i = 0; i < per - 1; i++) {
        const valorMedio = (amount - somaPartes) / BigInt(per - i);
        const variacao = BigInt(Math.floor(Math.random() * Number(valorMedio / 2n)));
        const parte = valorMedio + variacao;

        partes.push(parte);
        somaPartes += parte;
    }

    partes.push(amount - somaPartes);
    partes.sort(() => Math.random() - 0.5);

    return partes;
}

export function divideAmount(amount: bigint): [bigint, bigint] {
    const percentage = Math.random() * (0.7 - 0.3) + 0.3;
    const firstPart = BigInt(Math.floor(Number(amount) * percentage));
    const secondPart = amount - firstPart;

    return [firstPart, secondPart];
}

export function isBettweenTime(start: string, end: string): boolean {
    if (start != '00:00' || end != '00:00') {
        const currentTime = new Date();
        const currentHours = currentTime.getHours();
        const currentMinutes = currentTime.getMinutes();

        const [startHours, startMinutes] = start.split(':').map(Number);
        const [endHours, endMinutes] = end.split(':').map(Number);

        let isCurrentTimeWithinRange: boolean;

        if (endHours < startHours || (endHours === startHours && endMinutes < startMinutes)) {
            isCurrentTimeWithinRange = (currentHours > startHours || (currentHours === startHours && currentMinutes >= startMinutes)) ||
                (currentHours < endHours || (currentHours === endHours && currentMinutes <= endMinutes));
        } else {
            isCurrentTimeWithinRange = (currentHours > startHours || (currentHours === startHours && currentMinutes >= startMinutes)) &&
                (currentHours < endHours || (currentHours === endHours && currentMinutes <= endMinutes));
        }

        if (!isCurrentTimeWithinRange) {
            return false;
        }
    }

    return true;
}