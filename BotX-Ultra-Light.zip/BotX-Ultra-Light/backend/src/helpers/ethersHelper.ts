import { ethers, Signer } from "ethers";
import { countDecimals } from './functionsHelper';
import { ChainId, Currency, CurrencyAmount, Percent, Token, TradeType } from "@uniswap/sdk-core";
import { computePoolAddress, FeeAmount, Pool, Route, SwapOptions, SwapQuoter } from "@uniswap/v3-sdk";
import { settings } from '../utils/settings';
import IUniswapV3PoolABI from '@uniswap/v3-core/artifacts/contracts/interfaces/IUniswapV3Pool.sol/IUniswapV3Pool.json';
import contracts from '../utils/contracts.json';
import JSBI from 'jsbi';
import BlockchainHelper from "./blockchainHelper";
import { AcceptedToken } from "../models/AcceptedToken";

export async function getSigner(accountPrivateKey: string): Promise<Signer> {
    try {
        const blockchainHelper = new BlockchainHelper();
        const provider = blockchainHelper.getProvider();
        const signer = new ethers.Wallet(accountPrivateKey, provider);

        return signer;
    } catch (error) {
        console.log('getSigner error');
        throw 'This private key is not valid';
    }
}

export async function getMaticBalance(signer: Signer): Promise<bigint> {
    try {
        if (!signer.provider) {
            return BigInt(0);
        }

        const address = await signer.getAddress();
        const balance = await signer.provider.getBalance(address)

        return balance;
    } catch (error) {
        console.log('getMaticBalance error');
        throw 'This private key is not valid';
    }
}

export async function getWmaticBalance(signer: Signer): Promise<bigint> {
    try {
        if (!signer.provider) {
            return BigInt(0);
        }

        const wmaticContract = new ethers.Contract(settings.WMATIC_ADDRESS, contracts.ERC20_ABI, signer);
        const address = await signer.getAddress();
        const balance = await wmaticContract.balanceOf(address);

        return balance;
    } catch (error) {
        console.log('getWmaticBalance error');
        throw error;
    }
}

export async function getSelectedTokenBalance(accountPrivateKey: string, tokenContractAddress: string): Promise<bigint> {
    try {
        const signer = await getSigner(accountPrivateKey);

        if (!signer.provider) {
            return BigInt(0);
        }

        const address = await signer.getAddress();
        const tokenContract = new ethers.Contract(tokenContractAddress, contracts.ERC20_ABI, signer);
        const balance = await tokenContract.balanceOf(address);

        return balance;
    } catch (error) {
        console.log('getSelectedTokenBalance error');
        throw error;
    }
}

export async function getSelectedTokenBalance2(signer: Signer, tokenContractAddress: string): Promise<bigint> {
    try {
        const address = await signer.getAddress();
        const tokenContract = new ethers.Contract(tokenContractAddress, contracts.ERC20_ABI, signer);
        const balance = await tokenContract.balanceOf(address);

        return balance;
    } catch (error) {
        console.log('getSelectedTokenBalance2 error');
        throw error;
    }
}

export async function generateNewWallet(provider: ethers.Provider): Promise<ethers.HDNodeWallet | null> {
    const newWallet = ethers.Wallet.createRandom(provider);

    if (!newWallet) {
        console.log('Error to create a new wallet');
        return null;
    }

    if (!ethers.isAddressable(newWallet)) {
        console.log('New wallet address is not addressable');
        return null;
    }

    if (!addressIsValid(newWallet.address)) {
        console.log('New wallet address is invalid');
        return null;
    }

    return newWallet;
}

export async function addressIsValid(address: string): Promise<boolean> {
    try {
        const isValid = ethers.isAddress(address);

        return isValid;
    } catch (error) {
        throw error;
    }
}

export async function fromReadableAmount(amount: number): Promise<any> {
    try {
        const extraDigits = Math.pow(10, await countDecimals(amount));
        const adjustedAmount = amount * extraDigits;

        const amountFrom = JSBI.divide(
            JSBI.multiply(
                JSBI.BigInt(adjustedAmount),
                JSBI.exponentiate(JSBI.BigInt(10), JSBI.BigInt(18))
            ),
            JSBI.BigInt(extraDigits)
        );

        return amountFrom;
    } catch (error) {
        console.log('fromReadableAmount error', error)
        throw (error);
    }
}

export function swapOptions(to: string, slippageTolerance: number): SwapOptions {
    const options: SwapOptions = {
        slippageTolerance: new Percent(slippageTolerance, 100),
        deadline: Math.floor(Date.now() / 1000) + 60 * 20,
        recipient: to
    };

    return options;
}

export async function findValidFee(signer: Signer, tokenA: Token, tokenB: Token): Promise<number | null> {
    const fees = [FeeAmount.LOWEST, FeeAmount.LOW, FeeAmount.MEDIUM, FeeAmount.HIGH];

    for (const fee of fees) {
        const poolAddress = computePoolAddress({
            factoryAddress: settings.UNISWAP_V3_ADDRESS,
            tokenA: tokenA,
            tokenB: tokenB,
            fee: fee,
        });

        const poolCode = await signer.provider!.getCode(poolAddress);

        if (poolCode !== '0x') {
            return fee;
        }
    }

    return null;
}

export function verifyWorstExecutionPrice(uncheckedTrade: any, acceptablePrice: number) {
    const worstPrice = uncheckedTrade.worstExecutionPrice(new Percent(1, 100));

    if (worstPrice.greaterThan(acceptablePrice)) {
        throw 'Price is too high'
    }
}

export async function getOutputQuote(route: Route<Currency, Currency>, signer: Signer, amount: bigint, tokenIn: Token): Promise<any> {
    try {
        const { calldata } = SwapQuoter.quoteCallParameters(
            route,
            CurrencyAmount.fromRawAmount(tokenIn, JSBI.BigInt(amount.toString())),
            TradeType.EXACT_INPUT,
            {
                useQuoterV2: true,
            }
        )

        const quoteCallReturnData = await signer.call({
            to: settings.UNISWAP_QUOTER_V2_ADDRESS,
            data: calldata,
        });

        const abiCoder = ethers.AbiCoder.defaultAbiCoder();
        const quote = abiCoder.decode(['uint256'], quoteCallReturnData);

        return quote;
    } catch (error) {
        console.log('getOutputQuote error');
        throw (error);
    }
}

export async function poolConstants(signer: Signer, tokenA: Token, tokenB: Token): Promise<Pool> {
    try {
        const validFee = await findValidFee(signer, tokenA, tokenB);

        if (!validFee) {
            throw new Error(`Valid fee not found at pool ${tokenA.symbol} / ${tokenB.symbol}`);
        }

        const currentPoolAddress = computePoolAddress({
            factoryAddress: settings.UNISWAP_V3_ADDRESS,
            tokenA: tokenA,
            tokenB: tokenB,
            fee: validFee,
        });

        const poolCode = await signer.provider!.getCode(currentPoolAddress);


        if (poolCode === '0x') {
            throw new Error(`No contract deployed at pool ${tokenA.symbol} / ${tokenB.symbol}`);
        }

        const poolContract = new ethers.Contract(currentPoolAddress, IUniswapV3PoolABI.abi, signer.provider);
        const fee = await poolContract.fee();
        const liquidity = await poolContract.liquidity();
        const slot0 = await poolContract.slot0();

        const pool = new Pool(
            tokenA,
            tokenB,
            Number(fee.toString()),
            slot0[0].toString(),
            liquidity.toString(),
            Number(slot0[1])
        );

        return pool;
    } catch (error) {
        console.log('poolConstants error');
        throw (error);
    }
}

export async function getTokenPrice(signer: Signer, tokenAddress: string, tokenSymbol: string, tokenName: string, decimals: number, poolDetails: AcceptedToken | null): Promise<number> {
    try {
        const tokenA = new Token(ChainId.POLYGON, tokenAddress, decimals, tokenSymbol, tokenName);

        let tokenB;

        if (!poolDetails) {
            tokenB = new Token(ChainId.POLYGON, settings.WMATIC_ADDRESS, 18, "WMATIC", "Wrapped Matic");
        } else {
            tokenB = new Token(ChainId.POLYGON, poolDetails.pool_address, poolDetails.pool_decimals, poolDetails.pool_symbol, poolDetails.pool_name);
        }

        const pool = await poolConstants(signer, tokenA, tokenB);

        const quoteAmount = BigInt(2 ** 192 * 1 * 10 ** tokenA.decimals) / BigInt(Number(pool.sqrtRatioX96) ** 2);
        const quoteAmountInDecimal = Number(quoteAmount.toString()) / (10 ** tokenB.decimals);
        return quoteAmountInDecimal;
    } catch (error) {
        console.log('getTokenPrice error');
        throw (error);
    }
}
