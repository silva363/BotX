import { Signer, TransactionRequest, ethers } from "ethers";
import { ChainId, CurrencyAmount, Token, TradeType } from "@uniswap/sdk-core";
import { poolConstants, fromReadableAmount, getOutputQuote, swapOptions } from './ethersHelper';
import { getTokenTransferApproval, sendTransaction } from "./transferHelper";
import { getGasFeePrices } from "./cryptoHelper";
import { settings } from '../utils/settings';
import { TransactionResponse } from "../models/TransactionResponse.model";
import JSBI from "jsbi";
import { Route, SwapRouter, Trade } from "@uniswap/v3-sdk";
import { AcceptedTokenRepository } from "../repositories/acceptedTokenRepository";
import { AcceptedToken } from "@/models/AcceptedToken";

export async function sell(
    signer: Signer,
    amount: bigint,
    selectedTokenName: string,
    selectedTokenSymbol: string,
    selectedTokenAddress: string,
    tokenDetails: AcceptedToken,
    slippageTolerance: number
): Promise<TransactionResponse> {
    try {
        console.log('Starting swap sell...');
        const selectedToken = new Token(ChainId.POLYGON, selectedTokenAddress, tokenDetails.decimals, selectedTokenSymbol, selectedTokenName);
        let getFeeData = await getGasFeePrices();
        const walletAddress = await signer.getAddress();

        let isApproved = await getTokenTransferApproval(signer, selectedToken.address, getFeeData.gasPrice);
        let count = 0;

        while (!isApproved && count < 10) {
            await new Promise(resolve => setTimeout(resolve, 20000));
            getFeeData = await getGasFeePrices();
            isApproved = await getTokenTransferApproval(signer, selectedToken.address, getFeeData.gasPrice);
            count + 1;
        }

        const trade = await createTrade(signer, amount, selectedToken);
        const options = swapOptions(walletAddress, slippageTolerance);
        const swapCallParams = SwapRouter.swapCallParameters([trade], options);

        const tx: TransactionRequest = {
            data: swapCallParams.calldata,
            to: settings.UNISWAP_ROUTER_V3_ADDRESS,
            value: BigInt(swapCallParams.value),
            gasPrice: getFeeData.gasPrice
        }

        return await sendTransaction(tx, signer);
    } catch (error: any) {
        console.log('Transaction [sell] error');
        return { hash: '', status: 0, message: JSON.stringify(error), result: [] };
    }
}

async function createTrade(
    signer: Signer,
    amount: bigint,
    selectedToken: Token
) {
    try {
        const acceptedTokenRepository = new AcceptedTokenRepository();
        const tokenDetails = await acceptedTokenRepository.findByAddress(selectedToken.address);

        if (!tokenDetails) {
            throw 'Token details not found';
        }

        const tokenB = new Token(ChainId.POLYGON, tokenDetails.pool_address, tokenDetails.pool_decimals, tokenDetails.pool_symbol, tokenDetails.pool_name);
        const pool = await poolConstants(signer, selectedToken, tokenB);
        const swapRoute = new Route([pool], selectedToken, tokenB);
        const inputAmount = CurrencyAmount.fromRawAmount(selectedToken, JSBI.BigInt(amount.toString()));
        const amountOut = await getOutputQuote(swapRoute, signer, amount, selectedToken);
        const outputAmount = CurrencyAmount.fromRawAmount(tokenB, JSBI.BigInt(amountOut));

        const uncheckedTrade = Trade.createUncheckedTrade({
            route: swapRoute,
            inputAmount: inputAmount,
            outputAmount: outputAmount,
            tradeType: TradeType.EXACT_INPUT,
        });

        return uncheckedTrade;
    } catch (error) {
        console.log('createTrade error');
        throw (error);
    }
}