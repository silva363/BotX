import { Signer, TransactionRequest, ethers } from "ethers";
import { ChainId, Token } from "@uniswap/sdk-core";
import { findValidFee } from './ethersHelper';
import { getTokenTransferApproval, sendTransaction } from "./transferHelper";
import { getGasFeePrices } from "./cryptoHelper";
import { settings } from '../utils/settings';
import { abi as V3SwapRouterABI } from '@uniswap/v3-periphery/artifacts/contracts/SwapRouter.sol/SwapRouter.json';
import { TransactionResponse } from "../models/TransactionResponse.model";
import { AcceptedToken } from "../models/AcceptedToken";

export async function buy(signer: Signer, amount: bigint, tokenDetails: AcceptedToken, slippageTolerance: number): Promise<TransactionResponse> {
    try {
        console.log('Starting swap buy...');
        const selectedToken = new Token(ChainId.POLYGON, tokenDetails.address, tokenDetails.decimals, tokenDetails.symbol, tokenDetails.name);
        let getFeeData = await getGasFeePrices();
        const walletAddress = await signer.getAddress();
        const maticTax = getFeeData.gasPrice * BigInt(300000);
        let finalAmount = amount;

        if (tokenDetails.pool_symbol == 'WPOL' || tokenDetails.pool_symbol == 'WMATIC') {
            finalAmount = amount - maticTax;
        }

        let isApproved = await getTokenTransferApproval(signer, tokenDetails.pool_address, getFeeData.gasPrice);
        let count = 0;

        while (!isApproved && count < 10) {
            await new Promise(resolve => setTimeout(resolve, 20000));
            getFeeData = await getGasFeePrices();
            isApproved = await getTokenTransferApproval(signer, selectedToken.address, getFeeData.gasPrice);
            count + 1;
        }

        const trade = await createTrade(signer, finalAmount, walletAddress, selectedToken, tokenDetails);

        const tx: TransactionRequest = {
            to: settings.UNISWAP_ROUTER_V3_ADDRESS,
            from: walletAddress,
            data: trade,
            value: finalAmount,
            gasPrice: getFeeData.gasPrice
        };

        return await sendTransaction(tx, signer);
    } catch (error: any) {
        console.log('Transaction [buy] error');
        return { hash: '', status: 0, message: JSON.stringify(error), result: [] };
    }
}

async function createTrade(signer: Signer, amount: bigint, to: string, selectedToken: Token, tokenDetails: AcceptedToken) {
    try {
        const tokenA = new Token(ChainId.POLYGON, tokenDetails.pool_address, tokenDetails.pool_decimals, tokenDetails.pool_symbol, tokenDetails.pool_name);
        const router = new ethers.Contract(settings.UNISWAP_ROUTER_V3_ADDRESS, V3SwapRouterABI);
        const deadline = Math.floor(Date.now() / 1000) + 60 * 20;

        const validFee = await findValidFee(signer, tokenA, selectedToken);

        if (!validFee) {
            throw new Error(`Valid fee not found at pool ${tokenA.symbol} / ${selectedToken.symbol}`);
        }

        const params = {
            tokenIn: tokenA.address,
            tokenOut: selectedToken.address,
            fee: validFee,
            recipient: to,
            deadline: deadline,
            amountIn: amount,
            amountOutMinimum: 0,
            sqrtPriceLimitX96: 0
        };

        const trade = router.interface.encodeFunctionData('exactInputSingle', [params]);

        return trade;
    } catch (error) {
        console.log('createTrade error');
        throw (error);
    }
}