import { settings } from '../utils/settings';
import { Alchemy, Network } from "alchemy-sdk";

const sdkSettings = {
    apiKey: settings.ALCHEMY_KEY,
    network: Network.MATIC_MAINNET,
};

const alchemy = new Alchemy(sdkSettings);

export async function getGasFeePrices(): Promise<{ gasPrice: bigint, lastBaseFeePerGas: bigint, maxFeePerGas: bigint, maxPriorityFeePerGas: bigint }> {
    try {
        const getFeeData = await alchemy.core.getFeeData();

        if (!getFeeData || !getFeeData.gasPrice || !getFeeData.lastBaseFeePerGas || !getFeeData.maxFeePerGas || !getFeeData.maxPriorityFeePerGas) {
            throw 'Error to get gas fee price';
        }

        const data = {
            gasPrice: BigInt(getFeeData.gasPrice.mul(115).div(100).toString()),
            lastBaseFeePerGas: BigInt(getFeeData.lastBaseFeePerGas.toString()),
            maxFeePerGas: BigInt(getFeeData.maxFeePerGas.toString()),
            maxPriorityFeePerGas: BigInt(getFeeData.maxPriorityFeePerGas.toString())
        };

        return data;
    } catch (error) {
        if (error instanceof Error) {
            throw error.message;
        } else {
            throw error;
        }
    }
}