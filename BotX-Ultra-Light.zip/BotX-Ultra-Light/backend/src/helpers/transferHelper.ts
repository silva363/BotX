import { ethers, Provider, Signer, TransactionRequest } from "ethers";
import { settings } from '../utils/settings';
import contracts from '../utils/contracts.json';
import { TransactionResponse } from "../models/TransactionResponse.model";

export async function getTokenTransferApproval(signer: Signer, address: string, gasPrice: bigint): Promise<boolean> {
    try {
        const walletAddress = await signer.getAddress();
        const tokenContract = new ethers.Contract(address, contracts.ERC20_ABI, signer);
        const allowance = await tokenContract.allowance(walletAddress, settings.UNISWAP_ROUTER_V3_ADDRESS);

        if (allowance < ethers.parseEther("5000")) {
            console.log('Sending transaction approve...');
            const approvalTransaction = await tokenContract.approve(settings.UNISWAP_ROUTER_V3_ADDRESS, ethers.MaxUint256, {
                gasPrice: gasPrice
            });

            console.log('Waiting transaction approve...');
            const approvalReceipt = await approvalTransaction.wait();

            if (approvalReceipt.status === 1) {
                console.log('Transaction approved');
                return true;
            } else {
                console.error('Transaction not approved');
                return false;
            }
        } else {
            console.log('Already approved');
            return true;
        }
    } catch (error) {
        console.log('getTokenTransferApproval error');
        return false;
    }
}

export async function sendTransaction(transaction: TransactionRequest, signer: Signer): Promise<TransactionResponse> {
    try {
        if (!signer.provider) {
            throw 'You need a signer provider';
        }

        console.log(`Sending transaction...`);
        const txRes = await signer.sendTransaction(transaction);

        console.log(`Awaiting transaction confirmations...`);
        await txRes.wait(settings.TX_APPROVALS);

        return await getReceipt(signer.provider, txRes.hash);
    } catch (error) {
        console.log('sendTransaction error');
        throw error;
    }
}

async function getReceipt(
    provider: Provider,
    txHash: string,
    retries: number = 5,
    delayMs: number = 3000
): Promise<TransactionResponse> {
    let attempt = 0;

    while (attempt < retries) {
        try {
            console.log(`Awaiting transaction receipt ${attempt + 1}/${retries}...`);
            const receipt = await provider.getTransactionReceipt(txHash);

            if (receipt) {
                const status = receipt.status === 1 ? 1 : 2;
                const message = status === 1 ? 'Transfer success' : 'Transfer fail';

                return { hash: txHash, message, result: receipt, status };
            }

        } catch (error) {
            console.log(`Get transaction receipt error on attempt ${attempt + 1}/${retries}`);
        }

        attempt++;

        if (attempt < retries) {
            await new Promise(resolve => setTimeout(resolve, delayMs));
        }
    }

    throw new Error(`getReceipt error`);
}

