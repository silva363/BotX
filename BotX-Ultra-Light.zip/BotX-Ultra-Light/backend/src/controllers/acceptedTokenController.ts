import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import { AcceptedTokenService } from '../services/acceptedTokenService';
import { format } from '../helpers/formatReturnData';

export class AcceptedTokenController {
    private acceptedTokenService: AcceptedTokenService;

    constructor() {
        this.acceptedTokenService = new AcceptedTokenService();
    }

    async create(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { name, symbol, address, decimals, pool_address, pool_name, pool_symbol, pool_decimals } = req.body;

            await this.acceptedTokenService.create(name, symbol, address, Number(decimals), pool_address, pool_name, pool_symbol, Number(pool_decimals));

            res.status(201).json({ message: 'Token [create] success', data: [], success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }

    async edit(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { id, name, symbol, address, decimals, pool_address, pool_name, pool_symbol, pool_decimals } = req.body;

            await this.acceptedTokenService.edit(Number(id), name, symbol, address, Number(decimals), pool_address, pool_name, pool_symbol, Number(pool_decimals));

            res.status(201).json({ message: 'Token [edit] success', data: [], success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }

    async changeActive(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { id } = req.body;

            const response = await this.acceptedTokenService.changeActive(Number(id));

            res.status(201).json({ message: `Token [${response}] success`, data: [], success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }

    async list(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { } = req.body;

            const data = await this.acceptedTokenService.list();

            res.status(201).json({ message: 'Token [list] success', success: true, data: format(data) });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, success: false, data: [] });
            } else {
                res.status(200).json({ message: err, success: false, data: [] });
            }
        }
    }
}
