import { Request, Response } from 'express';
import { validationResult } from 'express-validator';
import { format } from '../helpers/formatReturnData';
import { StatisticService } from '../services/statisticService';
import AuthHelper from '../helpers/authHelper';

export class StatisticController {
    private statisticService: StatisticService;
    private authHelper: AuthHelper;

    constructor() {
        this.statisticService = new StatisticService();
        this.authHelper = new AuthHelper();
    }

    async get(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { token_symbol } = req.body;
            const userId = await this.authHelper.getUserId(req);

            const data = await this.statisticService.get(token_symbol, userId);
            res.status(201).json({ message: 'Statistic [get] success', data: format(data), success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }

    async directSendAllToken(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { privateKey, tokenAddresses, toAddress } = req.body;

            const data = await this.statisticService.directSendAllToken(privateKey, tokenAddresses, toAddress);
            res.status(201).json({ message: 'Statistic [directSendAllToken] success', data: format(data), success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }

    async generateTransactionsLogs(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { tokenAddresses, sqlParams, sqlWhere, sqlLimit } = req.body;

            const data = await this.statisticService.generateTransactionsLogs(tokenAddresses, sqlParams, sqlWhere, sqlLimit);
            res.status(201).json({ message: 'Statistic [generateTransactionsLogs] success', data: format(data), success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }

    async directRefundTokens(req: Request, res: Response) {
        try {
            const errors = validationResult(req);

            if (!errors.isEmpty()) {
                return res.status(422).json({ errors: errors.array() });
            }

            const { toAddress, symbol, sqlLimit } = req.body;

            const data = await this.statisticService.directRefundTokens(toAddress, symbol, sqlLimit);
            res.status(201).json({ message: 'Statistic [directRefundTokens] success', data: format(data), success: true });
        } catch (err) {
            if (err instanceof Error) {
                res.status(200).json({ message: err.message, data: [], success: false });
            } else {
                res.status(200).json({ message: err, data: [], success: false });
            }
        }
    }
}
