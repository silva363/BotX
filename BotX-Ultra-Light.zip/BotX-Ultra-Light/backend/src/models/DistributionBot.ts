import { DistributionBotWallet } from "./DistributionBotWallet";

export interface DistributionBot {
  id?: number,
  uuid: string,
  user_id: number,
  name: string,
  password: string,
  account_private_key: string,
  account_friendly_name: string,
  token_symbol: string,
  delay: number,
  wallets?: DistributionBotWallet[],
  active: boolean,
  is_hidden?: boolean
}