

export interface Bot {
  id?: number,
  uuid: string,
  user_id: number,
  name: string,
  bot_address: number,
  target_price: number,
  min_amount: number,
  max_amount: number,
  min_delay: number,
  max_delay: number,
  target_balance: number,
  holder_percent: number,
  slippage_tolerance: number,
  delay_to_start?: number,
  type: string,
  active: boolean,
  active_airdrop: boolean,
  need_wait: boolean,
  account_private_key?: string,
  is_hidden?: boolean
}