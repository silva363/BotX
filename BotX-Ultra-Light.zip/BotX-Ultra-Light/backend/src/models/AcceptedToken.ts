

export interface AcceptedToken {
  id: number,
  name: string,
  symbol: string,
  address: string,
  decimals: number,
  pool_address: string,
  pool_name: string,
  pool_symbol: string,
  pool_decimals: number,
  active: boolean
}