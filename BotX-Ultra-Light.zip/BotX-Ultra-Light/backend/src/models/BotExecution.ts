export interface BotExecution {
  id?: number,
  bot?: number,
  trade_bot?: number,
  distribution_bot?: number,
  seed_bot?: number,
  volume_bot?: number,
  execution_time: number,
  active: number
}