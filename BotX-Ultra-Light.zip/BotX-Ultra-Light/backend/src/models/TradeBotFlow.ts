

export interface TradeBotFlow {
  id?: number,
  trade_bot: number,
  bot_execution: number,
  flow: number,
  actual_cycle: number,
}