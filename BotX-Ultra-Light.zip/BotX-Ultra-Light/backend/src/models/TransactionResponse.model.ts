

export interface TransactionResponse {
  hash: string,
  message: string,
  result: any,
  status: number
}