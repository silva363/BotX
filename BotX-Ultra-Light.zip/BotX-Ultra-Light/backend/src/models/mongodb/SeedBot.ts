import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

const SeedBotSchema = new mongoose.Schema({
  uuid: {
    type: String,
    default: uuidv4,
    unique: true
  },
  name: {
    type: String,
    required: true
  },
  token_name: String,
  token_symbol: String,
  token_address: {
    type: String,
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  cycles: {
    type: Number,
    required: true
  },
  cycle_delay: {
    type: Number,
    required: true
  },
  cycle_ghosts: {
    type: Number,
    required: true
  },
  active: {
    type: Boolean,
    default: false
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
});

// Update the updated_at field on save
SeedBotSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

export default mongoose.models.SeedBot || mongoose.model('SeedBot', SeedBotSchema);
