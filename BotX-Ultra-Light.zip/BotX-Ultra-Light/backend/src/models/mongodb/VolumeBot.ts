import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

const VolumeBotSchema = new mongoose.Schema({
  uuid: {
    type: String,
    default: uuidv4,
    unique: true
  },
  name: {
    type: String,
    required: true
  },
  token_name: String,
  token_symbol: String,
  token_address: {
    type: String,
    required: true
  },
  min_amount: {
    type: Number,
    required: true
  },
  max_amount: {
    type: Number,
    required: true
  },
  min_delay: {
    type: Number,
    required: true
  },
  max_delay: {
    type: Number,
    required: true
  },
  active: {
    type: Boolean,
    default: false
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
});

// Update the updated_at field on save
VolumeBotSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

export default mongoose.models.VolumeBot || mongoose.model('VolumeBot', VolumeBotSchema);
