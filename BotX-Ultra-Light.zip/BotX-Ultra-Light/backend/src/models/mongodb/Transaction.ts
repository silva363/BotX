import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';

const TransactionSchema = new mongoose.Schema({
  uuid: {
    type: String,
    default: uuidv4,
    unique: true
  },
  bot_uuid: {
    type: String,
    required: true
  },
  tx_hash: {
    type: String,
    unique: true,
    sparse: true
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed'],
    default: 'pending'
  },
  amount: Number,
  token_address: String,
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
});

// Update the updated_at field on save
TransactionSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

export default mongoose.models.Transaction || mongoose.model('Transaction', TransactionSchema);
