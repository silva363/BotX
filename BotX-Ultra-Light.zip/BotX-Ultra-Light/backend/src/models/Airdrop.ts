

export interface Airdrop {
  id?: number,
  user_id: number,
  bot_execution: number,
  private_key: string,
  amount: string,
  token_symbol: string,
  token_address: string,
  destiny_address: string,
  delay_to_start: number,
  status: number,
}