

export interface DistributionBotWallet {
  id: number,
  distribution_bot_uuid: string,
  name: string,
  wallet_address: string,
  percent: number
}