import { UserRepository } from "../repositories/userRepository";
import { settings } from "../utils/settings";
import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

interface AuthRequest extends Request {
  authtoken?: string;
}

export function signedGuard(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.header("authtoken")?.replace(" ", "");

  try {
    if (token === undefined || !token) {
      return res.status(401).json({ message: 'Jwt token not provided' });
    }

    jwt.verify(token, settings.JWT_SECRET_KEY, async (err, decoded: any) => {
      if (err) {
        console.log('signedGuard', err.message);
        return res.status(401).json({ message: `Jwt token ${err.message}` });
      } else if (decoded !== undefined && decoded.signWallet) {
        const signWallet = decoded.signWallet;

        const userRepository = new UserRepository();
        const userData = await userRepository.findByWallet(signWallet)
    
        if (!userData) {
          return res.status(401).json({ message: 'Your wallet cant access the system' });
        }

        next();
      }
    });
  } catch (error) {
    if (error instanceof Error) {
      return res.status(401).json({ message: error.message });
    }

    return res.status(401).json({ message: 'Try again later' });
  }
}