import { Request, Response, NextFunction } from "express";
import { settings } from '../utils/settings';

interface AuthRequest extends Request {
  authorization?: string;
}

export function authGuard(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.header("authorization")?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ message: "Authentication token not provided" });
  }

  try {
    const secretKey = settings.API_SECRET_KEY || "";

    if (secretKey != token) {
      return res.status(401).json({ message: "Invalid access token" });
    }

    next();
  } catch (error) {
    if (error instanceof Error) {
      return res.status(401).json({ message: error.message });
    }

    return res.status(401).json({ message: 'Try again later' });
  }
}